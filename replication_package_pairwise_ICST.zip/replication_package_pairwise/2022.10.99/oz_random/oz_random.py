import shutil
import string
import time
import subprocess
import os
from datetime import datetime
import copy
from operator import itemgetter
from lxml import etree
import numpy as np
import re
from tqdm import tqdm  # for the progress bar
import csv

"""
NOTES:

Go to the bottom to see the parameters that you can change!

1) in the template, comments like <!-- comment text --> are counted as elements by lmxl, which will try to parse them.
Do not put comments.
2) Remember to not include params directly in the "root" node, but just inside the other nodes, like "row"
3) Sometimes the TAF templates have nodes with min="1" max="1" and sometimes just nb_instances=1. "boolean" parameters
have (values="True;False" weights="1;1"), sometimes not.
4) ALWAYS use root as the root name, like <root name="root">, otherwise the choices will always be unsat
5) in XPath, // is equal to descendant-or-self, and will look recursively in the entire tree, so it is always better to use .// or a direct path
6) in XPATH //name[something][smthg] is equivalent to //name[something and smthg] while "|" is in parallel and gives two sets joined together, not an intersection
7) lxml starting index is 1, not 0 like in elementTree. e.g., the path to the first row node is root/row[1]
8) do not use dots "." and hyphens '-' in the names of the values fr type "string", otherwise, if it appears in the
    constraint expression, you will get Lexer.py", line 183, in __extract_dot    raise NameError
    or ValueError: 'config' is not in list . This should be said or fixed
9) <!-- comments --> like this can be inside TAF templates, but they are included in the lxml parsing, so remove them.
10) remember that TAF uses instances 0/0 indicating (index of this instance / max index of the nb_instances), with index nb_instances starting from 0
11) Sentences is a name to include pairs and single choices.
12) If in the other script and in the folder names there is 'random', it means the unguided approach. """


########################################################################
# work with files and directories
########################################################################

def create_dir(directory):
    # directory = '../experiment'
    if not os.path.exists(directory):
        os.makedirs(directory)


def move_folder(origin, target):
    shutil.move(origin, target)


def rm_folder_content(folder):
    for filename in os.listdir(folder):
        file_path = os.path.join(folder, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)  # shutil.rmtree() deletes a directory and all its contents.
        except Exception as e:
            print('Failed to delete %s. Reason: %s' % (file_path, e))


########################################################################
# color the text in the terminal
########################################################################

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


########################################################################
# Create test cases for TAF from pairs
########################################################################

########################################################################
# TAF related
########################################################################

def taf_overwrite_setting(setting_name, setting_value):
    os.system("python3 Taf.py silent overwrite set " + str(setting_name) + " " + str(setting_value))
    #  "!" at the end is not needed anymore


def taf_parse_generate():  # this works just if exit() has been added to the preloop in TAF
    print("Waiting for TAF to generate, this could take a while...")
    os.system("python3 Taf.py silent overwrite parse_template generate")  # OR: generate stat)


def exec_taf(timeout_taf):
    # NOTE: timeout_taf is a function of the template size/complexity and the number of constraints
    try:
        # Parse the template pointed by setting.xml and generate test cases
        taf_cmd = ["python3", "Taf.py", "parse_template", "generate"]
        print(">>> TAF is generating, it could take some time")
        print(">>> The timeout is set to " + str(timeout_taf) + "seconds")
        result = subprocess.run(taf_cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                timeout=timeout_taf)  # ,cwd="taf/src/",
        # could use subprocess.Popen instead
        if result.returncode == 0:
            print(">>> TAF has generated correctly")
            return True
        elif result.returncode != 0:
            # I have modified TAF to return 1 when the test_case doesn't respect the template, it should be managed better.
            print(">>> TAF had problem generating the test cases")
            return False
    except Exception as e:
        print(
            f"{bcolors.WARNING}\n Exception ERROR. TAF encountered issues, or it could not generate a test case with the provided values \n{bcolors.ENDC}")
        return False
    except subprocess.TimeoutExpired:
        print(f'Timeout for {taf_cmd} ({timeout_taf}s) expired')
        return False


def convert_TAF_tmplt_to_std_xml(root,
                                 is_template):  # or istempalte, or istestcase. the test case loses the integer, float, etc types, there is just "parameter"
    for child in root:
        if child.tag == "parameter":
            child.tag = child.attrib['name']
            if is_template:
                pass  # the type remains the same, integer, boolean, string, float
            else:
                child.attrib['type'] = 'parameter'
        elif child.tag == "node":
            child.tag = child.attrib['name']
            child.attrib['type'] = 'node'
            if 'instance' in child.attrib:
                child.attrib['nb_instances'] = str(int(child.attrib['instance'].split('/')[
                                                           1]) + 1)  # because instance(0/0) means the index 0 of/ the max index of the instances, which also starts from zero
                child.attrib['instance'] = child.attrib['instance'].split('/')[0]
            convert_TAF_tmplt_to_std_xml(child, is_template)
        else:
            print("Ignoring XML tag for child.tag =", child.tag)


def create_constr_expr_for_choice(elem_type1, choice_for_re, new_path):
    new_path = new_path[1:]  # IMPORTANT. Because TAF constraints expressions can start with ".\",
    # but it does not work with the root node. Eg. ".\row[i].nb_instances SUPEQ 1" inside /row/ or
    # "root_name\row.nb_instances inside /root_name/
    if elem_type1 == 'node' or elem_type1 == 'integer' or elem_type1 == 'real':
        lower_bound1 = re.search('>=(.+?) ', choice_for_re).group(1)
        upper_bound1 = re.search('<=(.+?)]', choice_for_re).group(1)
        if elem_type1 == "node":
            expr_choice_1 = new_path + ".nb_instances SUPEQ " + lower_bound1 + ", " + new_path + ".nb_instances INFEQ " + upper_bound1
        elif elem_type1 == "integer" or elem_type1 == "real":  # it is a parameter
            expr_choice_1 = new_path + " SUPEQ " + lower_bound1 + ", " + new_path + " INFEQ " + upper_bound1
            # should I add ";" at the end? No, it is added when joining the two sentences together
    elif elem_type1 == 'boolean' or elem_type1 == 'string':
        # search text inside  '@values=" ... "'
        bool_or_string_value1 = re.search('@values="(.+?)"', choice_for_re).group(1)
        expr_choice_1 = new_path + " EQ " + bool_or_string_value1  # no + ";" here, since it is a single expression
    else:
        raise ValueError("sentence['og_elem1']['type'] not implemented")
    return expr_choice_1


def create_path_with_brackets_and_count_quantifiers(elem_path1, indexes_of_lca1, indexes_list,
                                                    dict_quantifiers_and_paths, root_name):
    new_path1 = ''
    count_indexes_specific_elem1 = 0
    if indexes_of_lca1:
        first_quantif_lca = indexes_of_lca1[0]  # used just to store the first quantifier, used to fix the ranges in
    else:
        first_quantif_lca = ''  # Used to fix the problem below
    # the for loop below
    for elem in (re.split('(/)', elem_path1)[:-1]):
        if elem != '/' and elem != '' and elem != root_name:
            if indexes_of_lca1:
                popped_quantifier = indexes_of_lca1.pop(0)
                old_quantifier = popped_quantifier[:]
                if popped_quantifier == first_quantif_lca:  # the first upper bound doesn't have a quantif in the bound.
                    # The i+1 has quantif i inside
                    dict_quantifiers_and_paths.append({popped_quantifier: new_path1 + elem})
                else:
                    dict_quantifiers_and_paths.append(
                        {popped_quantifier: new_path1 + elem + '[{}]'.format(old_quantifier)})
                new_path1 += elem + '[{}]'.format(popped_quantifier)
            elif not indexes_of_lca1 and indexes_list:
                popped_quantifier = indexes_list.pop(0)
                old_quantifier = popped_quantifier[:]
                if popped_quantifier == first_quantif_lca:  # the first upper bound doesn't have a quantif in the bound.
                    # The i+1 has quantif i inside
                    dict_quantifiers_and_paths.append({popped_quantifier: new_path1 + elem})
                else:
                    dict_quantifiers_and_paths.append(
                        {popped_quantifier: new_path1 + elem + '[{}]'.format(old_quantifier)})
                new_path1 += elem + '[{}]'.format(popped_quantifier)
                dict_quantifiers_and_paths.append({popped_quantifier: new_path1})
                count_indexes_specific_elem1 += 1
        elif elem == '/' or elem == root_name:
            new_path1 += elem
    new_path1 += re.split('(/)', elem_path1)[-1]  # to add the last element/parameter
    return new_path1, count_indexes_specific_elem1


def generate_taf_constraint(sentence, sentence_index, root_name):
    # NOTE: this should be done using the TAF lexer and parsing the paths, not with regex
    # a sentence is in the form : ... copy from below
    # print("\n sentence=", sentence)

    """ IMPORTANT NOTE the indexes have to be different if they are inside the LCA path or not.
    #  So the indexes inside the first part of the path (the one of the LCA), have to be the same for elem1 and elem2,
    #  the following indexes should be different """
    indexes_list = list(
        string.ascii_lowercase)  # TAF accept quantifiers with max length =1, so 'i', 'j', and no 'ii' or 'lmn'

    # This is done to count how many indexes have to be the same between the two elements, as the indexes
    # that are the same are the ones related to the LCA
    lca_path = sentence['link']
    indexed_lca_path = ''
    for elem in (re.split('(/)', lca_path)):
        if elem != '/' and elem != '' and elem != root_name:
            indexed_lca_path += elem + '[{}]'
        elif elem == '/' or elem == root_name:
            indexed_lca_path += elem

    counter_lca = indexed_lca_path.count(
        "[{}]")  # used to know how many indexes have to be the same in the paths of the two elements

    indexes_of_lca1 = []
    indexes_of_lca2 = []
    if counter_lca != 0:  # to avoid the popping when there is /root, since count() returns "0", and pop(0) pops
        for i_counter in range(counter_lca):
            indexes_of_lca1.append(indexes_list.pop(0))
            indexes_of_lca2 = indexes_of_lca1.copy()

    dict_quantifiers_and_paths = []
    new_path1, count_indexes_specific_elem1 = create_path_with_brackets_and_count_quantifiers(sentence['elem1_path'],
                                                                                              indexes_of_lca1,
                                                                                              indexes_list,
                                                                                              dict_quantifiers_and_paths,
                                                                                              root_name)
    new_path2, count_indexes_specific_elem2 = create_path_with_brackets_and_count_quantifiers(sentence['elem2_path'],
                                                                                              indexes_of_lca2,
                                                                                              indexes_list,
                                                                                              dict_quantifiers_and_paths,
                                                                                              root_name)

    elem_type1 = sentence['og_elem1']['type']
    elem_type2 = sentence['og_elem2']['type']
    choice_for_re1 = sentence['choice1']
    choice_for_re2 = sentence['choice2']
    expr_choice_1 = create_constr_expr_for_choice(elem_type1, choice_for_re1, new_path1)
    expr_choice_2 = create_constr_expr_for_choice(elem_type2, choice_for_re2, new_path2)
    # is_self = sentence['is_self']

    expressions_str = "AND(" + expr_choice_1 + ", " + expr_choice_2  # the  + ")"  will be added later, depending in there is ", i DIF j" or not
    # IMPORTANT, because TAF uses "/" for the constraints, while "\" is the default for the paths and for lxml and xml
    expressions_str = expressions_str.replace('/', '\\')
    expressions_str = expressions_str.replace('root', '.')  # testforfix.root

    constr_name = 'sentence_' + str(sentence_index)
    name_str = '{}'.format(constr_name)
    types_str = ''  # e.g. "forall;exist"
    # expressions_str = ''
    quantifiers_str = ''  # e.g. "i;j"
    ranges_str = ''  # [0, tax_payer.nb_instances-1]

    # removing the duplicate entries.  This operation can invert the order of the quantifiers, e.g. you cna obtain c;a;b;d, so the result must be sorted, to avoid issues.
    dict_quantifiers_and_paths = [k for j, k in enumerate(dict_quantifiers_and_paths) if
                                  k not in dict_quantifiers_and_paths[j + 1:]]
    dict_quantifiers_and_paths = sorted(dict_quantifiers_and_paths, key=lambda d: list(d.keys()))

    min_num_quantif = 2  # the right way to do it is with a dict containing the number of instances of all the elements,
    # so it ispossible to check an element and say if there can be two indexes/quantifiers that are different. For now,
    # for Oz, the unfeasible/unsat pairs are filtered in the filter function.
    expr_part_to_add_for_dif = ''
    if len(dict_quantifiers_and_paths) >= min_num_quantif:  # fix for the self pairs (so with elems at the same level) which must have different indexes
        quantif_key_last_dict, value_1 = list(dict_quantifiers_and_paths[-1].items())[0]
        quantif_key_second_tolast_dict, value_2 = list(dict_quantifiers_and_paths[-2].items())[0]
        # remove the last quantif/index from the path, to check if they are the same
        path_without_last_quantif_last_dict = dict_quantifiers_and_paths[-1][quantif_key_last_dict]
        # cannot use replace(quantif_key_last_dict, ''), otherwise /tax_payer[a] will become tx_pyer[], and the comparison later will be false
        path_without_last_quantif_last_dict = path_without_last_quantif_last_dict.replace(
            '[' + quantif_key_last_dict + ']', '')
        path_without_last_quantif_secondlast_dict = dict_quantifiers_and_paths[-2][quantif_key_second_tolast_dict]
        path_without_last_quantif_secondlast_dict = path_without_last_quantif_secondlast_dict.replace(
            '[' + quantif_key_second_tolast_dict + ']', '')
        if path_without_last_quantif_last_dict == path_without_last_quantif_secondlast_dict:
            expr_part_to_add_for_dif = ', ' + quantif_key_last_dict + ' DIF ' + quantif_key_second_tolast_dict
        # 'i DIF j' to say in a TAF constraint that a quantifier has to be different from another one.
    for i_counter in range(len(dict_quantifiers_and_paths)):
        types_str = types_str + "exist;"
        dict_key = str(
            list(dict_quantifiers_and_paths[i_counter].keys())[0])  # dict is {'quantifier' : 'path without [..]'}
        quantifiers_str = quantifiers_str + dict_key + ';'
        upper_bound_range_path = dict_quantifiers_and_paths[i_counter][dict_key][1:]
        if upper_bound_range_path[-1] == ']':
            upper_bound_range_path = upper_bound_range_path[:-3]
        if dict_key == indexes_list[0]:  # IMPORTANT: remove first occurrence of [a], because in the first range the
            # quantifier is "a", so it is circular and will not work.
            upper_bound_range_path = re.sub('\[.*?\]', "", upper_bound_range_path, count=1)
        ranges_str = ranges_str + '[0, ' + upper_bound_range_path + '.nb_instances-1]; '
        # [1:] is to remove the first "\ before \root
    types_str = types_str[:-1]  # to remove the trailing ";"
    quantifiers_str = quantifiers_str[:-1]
    ranges_str = ranges_str[:-2]  # to remove "; " Yes, there is a space in ']; '.
    ranges_str = ranges_str.replace('/', '\\')  # To put the "\" that TAF accepts
    ranges_str = ranges_str.replace('root', '.')  # testforfix.root

    # replace root with .\ due to how TAF behaves, which rarely will not accept the full path with root\,
    #  so you should use .\. Substitute also in expressions.
    if len(dict_quantifiers_and_paths) == 0:  # fix for when the quantifiers are not needed and TAF does not allow empty fields "" for types_str
        expressions_str = expressions_str + ")"
        name_types_line = '<constraint name="' + name_str + '" \n'
        expressions_line = '\t expressions="' + expressions_str + '" \n'
        closing_the_constr = ' /> \n'

        new_constraint = name_types_line + expressions_line + closing_the_constr
    else:
        if expr_part_to_add_for_dif != '':  # this means that the quantif must be different (in TAF constr i DIF j)
            expressions_str = expressions_str + expr_part_to_add_for_dif + ")"
        else:
            expressions_str = expressions_str + ")"
        name_types_line = '<constraint name="' + name_str + '" types="' + types_str + '" \n'
        expressions_line = '\t expressions="' + expressions_str + '" \n'
        quantifiers_line = '\t quantifiers="' + quantifiers_str + '" \n'
        ranges_line = '\t ranges="' + ranges_str + '"'
        closing_the_constr = ' /> \n'

        new_constraint = name_types_line + expressions_line + quantifiers_line + ranges_line + closing_the_constr

    constraints_tree_elements = etree.Element('constraint', {'name': constr_name, 'types': types_str,
                                                             'expressions': expressions_str,
                                                             'quantifiers': quantifiers_str,
                                                             'ranges': ranges_str})
    return new_constraint, constraints_tree_elements


def create_single_constraint_from_choice(sentence, sentence_index, root_name, constr_index):
    # in thif fuction, the indexes are for a single choice, so they do not have be the same for the LCA, like in the sentence/pair
    indexes_list = list(string.ascii_lowercase)
    dict_quantifiers_and_paths = []

    if constr_index == str(1):  # We Should make it not hardcoded, for when there will be n-choices
        choice_for_re1 = sentence['choice1']
        elem_type1 = sentence['og_elem1']['type']
        elem_path = sentence['elem1_path']
    else:
        choice_for_re1 = sentence['choice2']
        elem_type1 = sentence['og_elem2']['type']
        elem_path = sentence['elem2_path']

    new_path1, count_indexes_specific_elem1 = create_path_with_brackets_and_count_quantifiers(elem_path,
                                                                                              [],
                                                                                              indexes_list,
                                                                                              dict_quantifiers_and_paths,
                                                                                              root_name)

    expr_choice_1 = create_constr_expr_for_choice(elem_type1, choice_for_re1, new_path1)

    expressions_str = expr_choice_1  # HERE "AND(" + + ")" is not needed, wrt the pair of choices, as it is a single element.
    expressions_str = expressions_str.replace('root', '.').replace('/', '\\')
    constr_name = 'sentence_' + str(sentence_index)
    constr_name = '{}'.format(constr_name + "_" + str(constr_index))
    types_str = ''  # e.g. "forall;exist"
    quantifiers_str = ''  # e.g. "i;j"
    ranges_str = ''  # [0, tax_payer.nb_instances-1]
    # removing the duplicate entries.  This operation can invert the order of the quantifiers, e.g. you can obtain c;a;b;d, so the result must be sorted, to avoid issues.
    dict_quantifiers_and_paths = [k for j, k in enumerate(dict_quantifiers_and_paths) if
                                  k not in dict_quantifiers_and_paths[j + 1:]]
    dict_quantifiers_and_paths = sorted(dict_quantifiers_and_paths, key=lambda d: list(d.keys()))

    for ind in range(len(dict_quantifiers_and_paths)):
        types_str = types_str + "exist;"
        dict_key = str(list(dict_quantifiers_and_paths[ind].keys())[0])  # dict is {'quantifier' : 'path without [..]'}
        # quantif_as_key = list(dict_quantifiers_and_paths[i].keys())[list(dict_quantifiers_and_paths[i].values()).index(val)] # from https://towardsdatascience.com/how-to-extract-key-from-python-dictionary-using-value-2b2f8dd2a995
        quantifiers_str = quantifiers_str + dict_key + ';'
        upper_bound_range_path = dict_quantifiers_and_paths[ind][dict_key][1:]
        if upper_bound_range_path[-1] == ']':
            upper_bound_range_path = upper_bound_range_path[:-3]
        # print("upper_bound_range_path =", upper_bound_range_path)
        if dict_key == indexes_list[0]:  # IMPORTANT: remove first occurrence of [a], because in the first range the
            # quantifier is "a", so it is circular and will not work.
            upper_bound_range_path = re.sub('\[.*?\]', "", upper_bound_range_path, count=1)
        ranges_str = ranges_str + '[0, ' + upper_bound_range_path + '.nb_instances-1]; '
        # [1:] is to remove the first "\ before \root
    types_str = types_str[:-1]  # to remove the trailing ";"
    quantifiers_str = quantifiers_str[:-1]
    ranges_str = ranges_str[:-2]  # to remove "; " Yes, there is a space in ']; '.
    ranges_str = ranges_str.replace('/', '\\')  # To put the "\" that TAF accepts
    ranges_str = ranges_str.replace('root', '.')  # testforfix.root
    expressions_str = expressions_str.replace('root', '.')  # testforfix.root
    #  replace root with .\ due to TAF, which rarely will not accept the full path with root\,
    #  so you should use .\. Substitute also in expressions.
    if len(dict_quantifiers_and_paths) == 0:  # fix for when the quantifiers are not needed and TAF does not allow empty fields "" for types_str
        name_types_line = '<constraint name="' + constr_name + '" \n'
        expressions_line = '\t expressions="' + expressions_str + '" \n'
        closing_the_constr = ' /> \n'

        new_constraint = name_types_line + expressions_line + closing_the_constr
    else:
        name_types_line = '<constraint name="' + constr_name + '" types="' + types_str + '" \n'
        expressions_line = '\t expressions="' + expressions_str + '" \n'
        quantifiers_line = '\t quantifiers="' + quantifiers_str + '" \n'
        ranges_line = '\t ranges="' + ranges_str + '"'
        closing_the_constr = ' /> \n'

        new_constraint = name_types_line + expressions_line + quantifiers_line + ranges_line + closing_the_constr

    if types_str == '':  # if there are no quantifiers, types,and ranges, the TAf contraints have to be without the "types=" written, otherwise TAF will nto work
        single_constraint_tree_element = etree.Element('constraint', {'name': constr_name,
                                                                      'expressions': expressions_str})
    else:
        single_constraint_tree_element = etree.Element('constraint', {'name': constr_name, 'types': types_str,
                                                                      'expressions': expressions_str,
                                                                      'quantifiers': quantifiers_str,
                                                                      'ranges': ranges_str})
    return new_constraint, single_constraint_tree_element


########################################################################
# Various
########################################################################


def filter_impossible_sentences_tax_payer_from_taf_constraints(sentences, template_path):
    # the sentences/pairs have been obtained empirically
    idx_of_forbidden_sentences = []
    filtered_sentences = []  # just in case
    if template_path == '../templates/taxPayerExample/tax_payer_upd.template':
        forbidden_combinations = [
            '/root/tax_payer[disability_rate[@values>=0.33334 and @values<=0.66667]][disability_type[@values="None"]]',
            '/root/tax_payer[disability_rate[@values>=0.66668 and @values<=1.0]][disability_type[@values="None"]]',
            '/root/tax_payer[is_resident[@values="False"]][address/country[@values="LU"]]',
            '/root/tax_payer[count(child)>=0 and count(child)<=0][child/birth_year[@values',
            # this corresponds to 3 unsat_sentences
            '/root/tax_payer[count(child)>=0 and count(child)<=0][child/disability_rate[',  # 3 here too
            '/root/tax_payer[count(child)>=0 and count(child)<=0][child/disability_type[',
            '/root/tax_payer[count(child)>=0 and count(child)<=0][child[count(address)',
            '/root/tax_payer[count(child)>=0 and count(child)<=0][child/address/country[@',  # 5 here
            '/root/tax_payer/child[disability_rate[@values>=0.33334 and @values<=0.66667]][disability_type[@values="None"]]',
            '/root/tax_payer/child[disability_rate[@values>=0.66668 and @values<=1.0]][disability_type[@values="None"]]',
            '/root/tax_payer[count(income_pension)>=0 and count(income_pension)<=0][income_pension/is_local[',  # 2
            '/root/tax_payer[count(income_pension)>=0 and count(income_pension)<=0][income_pension[count(tax_card)>=1.0 and count(tax_card)<=1.0]]',
            '/root/tax_payer[count(income_pension)>=1 and count(income_pension)<=1][count(income_employment)>=3 and count(income_employment)<=3]',
            '/root/tax_payer[count(income_pension)>=1 and count(income_pension)<=1][count(income_other)>=3 and count(income_other)<=3]',
            '/root/tax_payer[count(income_pension)>=2 and count(income_pension)<=2][count(income_employment)>=2 and count(income_employment)<=2]',
            '/root/tax_payer[count(income_pension)>=2 and count(income_pension)<=2][count(income_employment)>=3 and count(income_employment)<=3]',
            '/root/tax_payer[count(income_pension)>=2 and count(income_pension)<=2][count(income_other)>=2 and count(income_other)<=2]',
            '/root/tax_payer[count(income_pension)>=2 and count(income_pension)<=2][count(income_other)>=3 and count(income_other)<=3]',
            '/root/tax_payer[count(income_pension)>=2 and count(income_pension)<=2][count(income_other)>=3 and count(income_other)<=3]',
            '/root/tax_payer[count(income_pension)>=3 and count(income_pension)<=3][count(income_employment)>=1',
            '/root/tax_payer[count(income_pension)>=3 and count(income_pension)<=3][count(income_employment)>=2',
            '/root/tax_payer[count(income_pension)>=3 and count(income_pension)<=3][count(income_employment)>=3',
            '/root/tax_payer[count(income_pension)>=3 and count(income_pension)<=3][income_employment/is_local[',  # 2
            '/root/tax_payer[count(income_pension)>=3 and count(income_pension)<=3][income_employment[count(tax_card)>=1.0',
            '/root/tax_payer[count(income_pension)>=3 and count(income_pension)<=3][count(income_other)>=1',
            '/root/tax_payer[count(income_pension)>=3 and count(income_pension)<=3][count(income_other)>=2',
            '/root/tax_payer[count(income_pension)>=3 and count(income_pension)<=3][count(income_other)>=3',
            '/root/tax_payer[count(income_pension)>=3 and count(income_pension)<=3][income_other/is_local[',  # 2
            '/root/tax_payer[income_pension/is_local[@values="True"]][count(income_employment)>=3',
            '/root/tax_payer[income_pension/is_local[@values="True"]][count(income_other)>=3',
            '/root/tax_payer[income_pension/is_local[@values="False"]][count(income_employment)>=3',
            '/root/tax_payer[income_pension/is_local[@values="False"]][count(income_other)>=3',
            '/root/tax_payer[income_pension[count(tax_card)>=1.0 and count(tax_card)<=1.0]][count(income_employment)>=3',
            '/root/tax_payer[income_pension[count(tax_card)>=1.0 and count(tax_card)<=1.0]][count(income_other)>=3',
            '/root/tax_payer[count(income_employment)>=0 and count(income_employment)<=0][income_employment/is_local[',
            # 2
            '/root/tax_payer[count(income_employment)>=0 and count(income_employment)<=0][income_employment[count(tax_card)',
            '/root/tax_payer[count(income_employment)>=1 and count(income_employment)<=1][count(income_other)>=3',
            '/root/tax_payer[count(income_employment)>=2 and count(income_employment)<=2][count(income_other)>=2',
            '/root/tax_payer[count(income_employment)>=2 and count(income_employment)<=2][count(income_other)>=3',
            '/root/tax_payer[count(income_employment)>=3 and count(income_employment)<=3][count(income_other)>=1',
            '/root/tax_payer[count(income_employment)>=3 and count(income_employment)<=3][count(income_other)>=2',
            '/root/tax_payer[count(income_employment)>=3 and count(income_employment)<=3][count(income_other)>=3',
            '/root/tax_payer[count(income_employment)>=3 and count(income_employment)<=3][income_other/is_local',
            '/root/tax_payer[income_employment/is_local[@values="True"]][count(income_other)>=3',
            '/root/tax_payer[income_employment/is_local[@values="False"]][count(income_other)>=3',
            '/root/tax_payer[income_employment[count(tax_card)>=1.0 and count(tax_card)<=1.0]][count(income_other)>=3',
            '/root/tax_payer[count(income_other)>=0 and count(income_other)<=0][income_other/is_local[']

        for id_sent, sentence in enumerate(sentences):
            for forb_combi in forbidden_combinations:
                if forb_combi in sentence['link_xpath']:
                    idx_of_forbidden_sentences.append(id_sent)
        sentences, filtered_sentences = filter_sentences_(sentences, idx_of_forbidden_sentences)
    elif template_path == '../templates/ozExample/oz_upd.template':
        forbidden_combinations = [
            '/root[field[(count(row)>=1 and count(row)<=34) and ( (.//following-sibling::field[count(row)>=1 and count(row)<=34]) or (.//preceding-sibling::field[count(row)>=1 and count(row)<=34] ))]]',
            '/root[field/vegetable[@values="cabbage"]][field/vegetable[@values="leek"]]',
            '/root[field[(count(row)>=1 and count(row)<=34) and ( (.//following-sibling::field[count(row)>=35 and count(row)<=67]) or (.//preceding-sibling::field[count(row)>=35 and count(row)<=67] ))]]',
            '/root[field[(count(row)>=1 and count(row)<=34) and ( (.//following-sibling::field[count(row)>=68 and count(row)<=100]) or (.//preceding-sibling::field[count(row)>=68 and count(row)<=100] ))]]',
            '/root[field[(count(row)>=35 and count(row)<=67) and ( (.//following-sibling::field[count(row)>=68 and count(row)<=100]) or (.//preceding-sibling::field[count(row)>=68 and count(row)<=100] ))]]',
            '/root/field[count(row)>=68 and count(row)<=100][count(weed_area)>=2 and count(weed_area)<=35]',
            '/root/field[count(row)>=68 and count(row)<=100][count(weed_area)>=36 and count(weed_area)<=68]',
            '/root/field[count(row)>=68 and count(row)<=100][count(inner_track_width)>=0 and count(inner_track_width)<=0]',
            '/root/field[count(row)>=68 and count(row)<=100][count(inner_track_width)>=1 and count(inner_track_width)<=33]',
            '/root/field[count(row)>=68 and count(row)<=100][count(inner_track_width)>=34 and count(inner_track_width)<=66]',
            '/root/field[count(weed_area)>=2 and count(weed_area)<=35][count(inner_track_width)>=34 and count(inner_track_width)<=66]',
            '/root/field[count(inner_track_width)>=0 and count(inner_track_width)<=0][inner_track_width/gap',
            '/root[field[count(inner_track_width)>=0 and count(inner_track_width)<=0]][mission/is_first_track_outer[@values="False"]]',
            '/root/field[count(row)>=1 and count(row)<=34][count(weed_area)>=36 and count(weed_area)<=68]',
            '/root/field[count(row)>=1 and count(row)<=34][count(weed_area)>=69 and count(weed_area)<=101]',
            '/root/field[count(row)>=1 and count(row)<=34][count(inner_track_width)>=34 and count(inner_track_width)<=66]',
            '/root/field[count(row)>=1 and count(row)<=34][count(inner_track_width)>=67 and count(inner_track_width)<=99]',
            '/root/field[count(row)>=35 and count(row)<=67][count(inner_track_width)>=67 and count(inner_track_width)<=99]',
            '/root/field[count(row)>=35 and count(row)<=67][count(inner_track_width)>=1 and count(inner_track_width)<=33]',
            '/root/field[count(row)>=35 and count(row)<=67][count(inner_track_width)>=0 and count(inner_track_width)<=0]',
            '/root/field[count(row)>=35 and count(row)<=67][count(weed_area)>=69 and count(weed_area)<=101]',
            '/root/field[count(row)>=35 and count(row)<=67][count(weed_area)>=2 and count(weed_area)<=35]',
            '/root[mission/two_pass[@values="True"]][mission/two_pass[@values="False"]]',
            '/root[mission/is_first_track_outer[@values="True"]][mission/is_first_track_outer[@values="False"]]',
            '/root[mission/final_track_outer[@values="True"]][mission/final_track_outer[@values="False"]]',
            '/root[mission/is_track_side_at_left[@values="True"]][mission/is_track_side_at_left[@values="False"]]',
            '/root[mission/is_first_uturn_right_side[@values="True"]][mission/is_first_uturn_right_side[@values="False"]]',
            './/following-sibling::terrain',
            '/root/field[count(weed_area)>=36 and count(weed_area)<=68][count(inner_track_width)>=0 and count(inner_track_width)<=0]',
            '/root/field[count(weed_area)>=36 and count(weed_area)<=68][count(inner_track_width)>=1 and count(inner_track_width)<=33]',
            '/root/field[count(weed_area)>=36 and count(weed_area)<=68][count(inner_track_width)>=67 and count(inner_track_width)<=99]',
            '/root/field[count(weed_area)>=69 and count(weed_area)<=101][count(inner_track_width)>=0 and count(inner_track_width)<=0]',
            './/following-sibling::field',
            # because there is just 1 field in the template, so the xpath with this form will never be sat
            '/root[field[(count(row)>=68 and count(row)<=100) and ( (.//following-sibling::field[count(row)>=68 and count(row)<=100]) or (.//preceding-sibling::field[count(row)>=68 and count(row)<=100] ))]]',
            '/root[field[(count(row)>=35 and count(row)<=67) and ( (.//following-sibling::field[count(row)>=35 and count(row)<=67]) or (.//preceding-sibling::field[count(row)>=35 and count(row)<=67] ))]]',
            '/root/field[count(weed_area)>=69 and count(weed_area)<=101][count(inner_track_width)>=1 and count(inner_track_width)<=33]',
            '/root/field[count(weed_area)>=69 and count(weed_area)<=101][count(inner_track_width)>=34 and count(inner_track_width)<=66]',
            '/root/terrain[heightmap/roughness[@values>=0.0 and @values<=0.33333]][heightmap/roughness[',
            '/root/terrain[heightmap/roughness[@values>=0.33334 and @values<=0.66667]][heightmap/roughness[',
            '/root/terrain[heightmap/roughness[@values>=0.66668 and @values<=1.0]][heightmap/roughness[',
            '/root/terrain[heightmap/persistence[@values>=0.0 and @values<=0.23333]][heightmap/persistence',
            '/root/terrain[heightmap/persistence[@values>=0.23334 and @values<=0.46667]][heightmap/persistence',
            '/root/terrain[heightmap/persistence[@values>=0.46668 and @values<=0.7]][heightmap/persistence',
            '/root/field[count(weed_area)>=2 and count(weed_area)<=35][count(inner_track_width)>=67 and count(inner_track_width)<=99]',
            # added with the new approach, and inserting the self of the parameters. They cannot be sat because their
            # parent node has multiplicity=1, so no i DIF j in the quantifiers:
            'count(/root[count(field[vegetable[@values="cabbage"]])>1])>0',
            'count(/root[count(field[vegetable[@values="leek"]])>1])>0',
            'count(/root[field[count(row)>=1 and count(row)<=34]][field[count(row)>=35 and count(row)<=67]])>0',
            'count(/root[field[count(row)>=1 and count(row)<=34]][field[count(row)>=68 and count(row)<=100]])>0',
            'count(/root[field[count(row)>=35 and count(row)<=67]][field[count(row)>=68 and count(row)<=100]])>0',
            'count(/root[field[count(weed_area)>=2 and count(weed_area)<=35]][field[count(weed_area)>=36 and count(weed_area)<=68]])>0',
            'count(/root[field[count(weed_area)>=2 and count(weed_area)<=35]][field[count(weed_area)>=69 and count(weed_area)<=101]])>0',
            'count(/root[field[count(weed_area)>=36 and count(weed_area)<=68]][field[count(weed_area)>=69 and count(weed_area)<=101]])>0',
            'count(/root[field[count(inner_track_width)>=0 and count(inner_track_width)<=0]][field[count(inner_track_width)>=1 and count(inner_track_width)<=33]])>0',
            'count(/root[field[count(inner_track_width)>=0 and count(inner_track_width)<=0]][field[count(inner_track_width)>=34 and count(inner_track_width)<=66]])>0',
            'count(/root[field[count(inner_track_width)>=0 and count(inner_track_width)<=0]][field[count(inner_track_width)>=67 and count(inner_track_width)<=99]])>0',
            'count(/root[field[count(inner_track_width)>=1 and count(inner_track_width)<=33]][field[count(inner_track_width)>=34 and count(inner_track_width)<=66]])>0',
            'count(/root[field[count(inner_track_width)>=1 and count(inner_track_width)<=33]][field[count(inner_track_width)>=67 and count(inner_track_width)<=99]])>0',
            'count(/root[field[count(inner_track_width)>=34 and count(inner_track_width)<=66]][field[count(inner_track_width)>=67 and count(inner_track_width)<=99]])>0',
            'count(/root[count(mission[two_pass[@values="True"]])>1])>0',
            'count(/root[count(mission[two_pass[@values="False"]])>1])>0',
            'count(/root[count(mission[is_first_track_outer[@values="True"]])>1])>0',
            'count(/root[count(mission[is_first_track_outer[@values="False"]])>1])>0',
            'count(/root[count(mission[final_track_outer[@values="True"]])>1])>0',
            'count(/root[count(mission[final_track_outer[@values="False"]])>1])>0',
            'count(/root/field[row/disappearance_probability[@values>=20.00001 and @values<=30.0]][count(inner_track_width)>=0 and count(inner_track_width)<=0])>0',
            'count(/root[count(mission[is_track_side_at_left[@values="True"]])>1])>0',
            'count(/root[count(mission[is_track_side_at_left[@values="False"]])>1])>0',
            'count(/root[count(mission[is_first_uturn_right_side[@values="True"]])>1])>0',
            'count(/root[count(mission[is_first_uturn_right_side[@values="False"]])>1])>0',
            'count(/root/terrain[count(heightmap[roughness[@values>=0.0 and @values<=0.33333]])>1])>0',
            'count(/root/terrain[count(heightmap[roughness[@values>=0.33334 and @values<=0.66667]])>1])>0',
            'count(/root/terrain[count(heightmap[roughness[@values>=0.66668 and @values<=1.0]])>1])>0',
            'count(/root/terrain[count(heightmap[persistence[@values>=0.0 and @values<=0.23333]])>1])>0',
            'count(/root/terrain[count(heightmap[persistence[@values>=0.23334 and @values<=0.46667]])>1])>0',
            'count(/root/terrain[count(heightmap[persistence[@values>=0.46668 and @values<=0.7]])>1])>0'

        ]
        for id_sent, sentence in enumerate(sentences):
            for forb_combi in forbidden_combinations:
                if forb_combi in sentence['link_xpath']:  # sentence['sentence_name']:
                    idx_of_forbidden_sentences.append(id_sent)
        sentences, filtered_sentences = filter_sentences_(sentences, idx_of_forbidden_sentences)
    return sentences, filtered_sentences


def filter_sentences_(sentences,
                      indexes_list):  #almost the same as the other remove function, find a way to make it the same
    # remove sat sentences from sentences and add them to sat_sentences
    filtered_sentences = []
    cpt = 0  # counts the distance between the indexes of the two lists
    i = 0
    n = len(sentences)
    while i < n:
        if i + cpt in indexes_list:
            filtered_sentences.append(sentences.pop(i))
            cpt += 1
            n -= 1
        else:
            i += 1
    return sentences, filtered_sentences  # not really needed, as it is passed by reference


def create_xpath_for_float(**kwargs):
    num_partitions = int(kwargs['num_partitions'])
    og_element = kwargs['og_element']
    to_avoid_overlap_float = 0.00001
    to_avoid_overlap_int = 1
    # print("kwargs['og_element'] =", kwargs['og_element'])
    case_with_zero = False
    if 'min' in og_element:
        min_float = float(kwargs['og_element']['min'])
        max_float = float(kwargs['og_element']['max'])
        if min_float == 0 and kwargs['og_element']['type'] == 'node':
            case_with_zero = True
            min_float = 1  # fix for when the nb_instances ==0, which is a special case
    elif 'nb_instances' in og_element:  # A fix for TEMPLATES with nodes having nb_instances=1 instead of min and max
        min_float = float(og_element['nb_instances'])
        max_float = float(og_element['nb_instances'])
    list_of_bounds = create_partitions_float(min_float, max_float,
                                             num_partitions)
    ranges = []
    if case_with_zero:  # if the nb_instances==0, treat it as separate case
        ranges.insert(0, [0, 0])  # ranges = [[0, 0]]

    if min_float == max_float:
        num_partitions = 1
        ranges = [[min_float, max_float]]
    else:
        for i in range(len(list_of_bounds) - 1):
            ranges.append([round(list_of_bounds[i], 5),
                           round(list_of_bounds[i + 1], 5)])  # rounded to the max decimals that TAF can manage.
        for i in range(len(ranges) - 1):
            if ranges[i][1] == ranges[i + 1][0]:
                ranges[i + 1][0] = round((ranges[i + 1][
                                              0] + to_avoid_overlap_float),
                                         5)  # ADD +!, so the bounds are different and
                # partitions are not overlapping # IMPORTANT Added +0.00001 to avoid issues with ranges overlapping
                # and TAF generating a single values that is the overlap, then xpath cannot find two separate elements,
                # because there is just one with the value of the overlap
                # round() is used again to avoid the floating point error
        if kwargs['elem_type'] == 'integer' or kwargs['elem_type'] == 'node':

            int_ranges = []
            for couple in ranges:
                int_couple = []
                for elem in couple:
                    int_couple.append(int(elem))
                int_ranges.append(int_couple)
            ranges = int_ranges
            for i in range(len(ranges) - 1):  # if the upper bound of one couple is equal to lower bound of
                # another couple, add +1
                if ranges[i][1] == ranges[i + 1][0]:
                    ranges[i + 1][0] = ranges[i + 1][
                                           0] + to_avoid_overlap_int  # ADD +1, so the bounds are different and partitions are not overlapping

    partial_list_of_xpath_expressions = xpath_from_ranges_float(ranges, og_element)
    return partial_list_of_xpath_expressions


def create_partitions_float(start, stop, num):  # num: [int, optional] No. of samples to generate
    return np.linspace(start, stop, num + 1)  # if num is the number of partitions, add +1


def create_xpath_for_boolean(**kwargs):
    bool_element = kwargs['og_element']
    bool_range = bool_element["values"].split(";")  # ['True', 'False']
    partial_list_of_xpath_expressions = xpath_from_ranges_bool(bool_range, bool_element)
    return partial_list_of_xpath_expressions


def xpath_from_ranges_float(ranges, taf_elem):
    partial_list_of_choices = []

    for range_ in ranges:
        str_to_add = create_xpath_str(elem_type=taf_elem['type'],
                                      name=taf_elem['name'],
                                      bool_enum_pstn_value='',  # pstn = position() = index
                                      lower_bound=range_[0],
                                      upper_bound=range_[1],
                                      range2='')
        partial_list_of_choices.append(str_to_add)
    return partial_list_of_choices


def xpath_from_ranges_bool(ranges, taf_elem):
    partial_list_of_choices = []
    for range_TF in ranges:
        str_to_add = create_xpath_str(elem_type=taf_elem['type'],
                                      # =taf_elem['type'], # this is done because template has
                                      # boolean, but the instantiated TC has just 'parameter'
                                      name=taf_elem['name'],
                                      bool_enum_pstn_value=range_TF,  # pstn = position() = index
                                      lower_bound='',
                                      upper_bound='',
                                      range2='')
        partial_list_of_choices.append(str_to_add)
    return partial_list_of_choices


########################################################################
# XPATH
########################################################################

def create_xpath_str(**kwargs):
    # we should rewrite it with full paths and do not use this for creating the xpath for the choices,
    # since now we use one single XPATH expr to find the LCA, instead of two separate XPATH queries for choice1 and choice2
    # this was created for the first approach, but now we have changed it. It can be remove by changing how the script works.

    # @type="node" and @type="parameter" are redundant if there is @nb_instances (just for nodes) or
    # @values just for (params)
    # IMPORTANT: the @attributes' values must have "" around, otherwise xpath will not find them

    choices_dict = {
        'node': lambda d: '//*[count(//{})>={} and count(//{})<={}]'.format(d['name'], d['lower_bound'], d['name'],
                                                                            d['upper_bound']),
        'integer': lambda d: '//{}[@type="parameter" and @values>={} and @values<={}]'.format(d['name'],
                                                                                              d['lower_bound'],
                                                                                              d['upper_bound']),  #
        'real': lambda d: '//{}[@type="parameter" and @values>={} and @values<={}]'.format(d['name'], d['lower_bound'],
                                                                                           d['upper_bound']),
        'boolean': lambda d: '//{}[@type="parameter" and @values="{}"]'.format(d['name'],
                                                                               d['bool_enum_pstn_value']),
        'string': lambda d: '//{}[@type="parameter" and @values="{}"]'.format(d['name'],
                                                                              d['bool_enum_pstn_value']),
        # the name is 'string' to be complaint with TAF, but it is an enumeration.
        # Before it was bool_or_enum, because the xpath expression is the same, now they are separated
        'nested_node_par': lambda d: '//{}//{}[@values>={} and @values<={}]'.format(d['name'], d['name2'],
                                                                                    d['lower_bound'],
                                                                                    d['upper_bound']),
        # use python to check if they are from same parent
        'nested_node_node': lambda d: '//{}//{}'.format(d['name'], d['name2']),
        'position': lambda d: '//{}[position()=1]'.format(d['name'], d['bool_enum_posit_value']),
        'params_same_parent': lambda d: '//*[{}[@values="{}"] and {}[@values="{}"]]'.format(d['name'], d['lower_bound'],
                                                                                            d['name2'],
                                                                                            d['upper_bound']),
        # here the order is different, because of the syntax. Also, they are values, not upper or lower bounds,  # returns the parent
        'nodes_same_parent': lambda d: '//*[{}[@instance="{}"] and {}[@instance="{}"]]'.format(d['name'],
                                                                                               d['lower_bound'],
                                                                                               d['name2'],
                                                                                               d['upper_bound']),
        'same_num_children ': lambda d: '//{}/@nb_instances'.format(
            d['name'])}  # returns the values of the max, not the node.
    elem_ = kwargs['elem_type']
    xpath_str = choices_dict[elem_](kwargs)
    return xpath_str


def check_xpath_expr(xpath_str, tree):
    elements_satisfying_choices = tree.xpath(xpath_str)
    dict_elem = []

    if isinstance(elements_satisfying_choices, bool):  # this is here because with this formalization some results are
        # bool and some are a set of elements.
        return elements_satisfying_choices  # in this case it will be a boolean
    else:
        for i_choices, elem in enumerate(elements_satisfying_choices):
            dict_elem.append(elem.attrib)
            dict_elem[i_choices]['path'] = tree.getpath(elem)
        # to modify element:  dict_elem['attribute_to_modify'] = "xyz"
    return dict_elem


def is_float(element):
    try:
        float(element)
        return True
    except ValueError:
        return False


def find_LCA_path(path1, path2):  # , if none, returns '/'
    return os.path.commonpath([path1, path2])


def create_xpath_for_link(sentence):
    # 1) the variables needed for obtaining @values or nb_instances for the node/int/bool/string param of choice 1
    elem1_name = sentence['og_elem1']['name']
    elem2_name = sentence['og_elem2']['name']
    elem1_type = sentence['og_elem1']['type']
    elem2_type = sentence['og_elem2']['type']
    elem1_path = sentence['og_elem1']['path']
    elem2_path = sentence['og_elem2']['path']
    choice1 = sentence['choice1']
    choice2 = sentence['choice2']
    lca_link_path = sentence['link']
    is_self = sentence['is_self']

    # 2) build the partial xpath expressions (just the [..] part ) for choice 1 and choice 2
    partial_xpath_1, part_name_for_sentence1 = create_partial_xpath(elem1_type, choice1, elem1_name, lca_link_path,
                                                                    elem1_path)
    partial_xpath_2, part_name_for_sentence2 = create_partial_xpath(elem2_type, choice2, elem2_name, lca_link_path,
                                                                    elem2_path)

    sentence_part_name = part_name_for_sentence1 + '--' + part_name_for_sentence2
    # NOTE prefer direct paths instead of "//" when searching, because it is slower and looks in the entire tree,
    # so it has unintended consequences
    # NOTE in the xpath expr, the lca path already contains "/" at the beginning
    final_xpath = 'count({}[{}][{}])>0'.format(lca_link_path, partial_xpath_1, partial_xpath_2)  # this is here and not
    # in the if to not rewrite the same line multiple times
    # final_xpath = '{}[{}][{}]'.format(lca_link_path, partial_xpath_1, partial_xpath_2)  # this is here and not
    # in the if to not rewrite the same line multiple times

    elem_name = elem1_name  # just for consistency with the other function

    nodes_path_not_in_lca = substract(elem1_path, lca_link_path)  # os.path.relpath() is not good for this
    if nodes_path_not_in_lca != '':  # if elem1_path == lca_link_path, so it is empty
        if nodes_path_not_in_lca[0] == '/':
            nodes_path_not_in_lca = nodes_path_not_in_lca[1:]  # removes first "/", to xpath does not have it
    head_tail = os.path.split(nodes_path_not_in_lca)
    no_lca_no_elem_name = head_tail[0]  # the element that is not included in the LCA or in the elem name
    # example /root/A/B/C with LCA = /root/A so no_lca_no_elem_name = B
    # NOTE IMPORTANT: the xpath withfollowing-siblings makes sure that the children are different, so it imposes a
    # strict requirement. Otherwise a pair could be satisfied/covered even by a child with two different parameters.

    # in the self pair case with closest LCA, the LCA should always be at 2 levels from the node.
    # The form is choice1 /root/A/B/C and choice2 /root/A/B/C with LCA = /root/A .
    # search_str = '/wanted_lca[nodes_path_not_in_lca[( and ) and ( ( and ) or ( and ) )]]'  # that's the structure for self pairs
    # eg that works '/root/tax_payer[count(child)=0 and (.//following-sibling::tax_payer[count(child)=1] or .//preceding-sibling::tax_payer[count(child)=1])]'

    if is_self:  # to filter the self pairs of nodes or parameters that have the same ranges,
        # which must be treated with a special xpath expression
        # sentence_part_name = sentence_part_name + '_self_'
        if elem1_type == 'node':
            lower_bound1 = re.search('>=(.+?) ', choice1).group(1)
            upper_bound1 = re.search('<=(.+?)]', choice1).group(1)
            lower_bound2 = re.search('>=(.+?) ', choice2).group(1)
            upper_bound2 = re.search('<=(.+?)]', choice2).group(1)

            if lower_bound1 == lower_bound2 and upper_bound1 == upper_bound2:  # self with same ranges

                final_xpath = '{lca_link_path}[{no_lca_no_elem_name}[(count({elem_n})>={lb1} and count({elem_n})<={ub1}) and ' \
                              '( (.//following-sibling::{no_lca_no_elem_name}[count({elem_n})>={lb2} and count({elem_n})<={ub2}]) ' \
                              'or (.//preceding-sibling::{no_lca_no_elem_name}[count({elem_n})>={lb2} and count({elem_n})<={ub2}] ))]]'.format(
                    lca_link_path=lca_link_path, no_lca_no_elem_name=no_lca_no_elem_name, elem_n=elem_name,
                    lb1=lower_bound1, ub1=upper_bound1, lb2=lower_bound2, ub2=upper_bound2)

            else:  # self with different ranges. In this case, the normal XPath works without issues
                pass

        elif elem1_type == 'integer' or elem1_type == 'real':
            lower_bound1 = re.search('>=(.+?) ', choice1).group(1)
            upper_bound1 = re.search('<=(.+?)]', choice1).group(1)
            lower_bound2 = re.search('>=(.+?) ', choice2).group(1)
            upper_bound2 = re.search('<=(.+?)]', choice2).group(1)
            if lower_bound1 == lower_bound2 and upper_bound1 == upper_bound2:  # self pair with parameters and same ranges

                final_xpath = 'count({lca_link_path}[count({no_lca_no_elem_name}[{elem_n}[@values>={lb1} and @values<={ub1}]])>1])>0'.format(
                    lca_link_path=lca_link_path, no_lca_no_elem_name=no_lca_no_elem_name, elem_n=elem_name,
                    lb1=lower_bound1,
                    ub1=upper_bound1)  # Alternative1, easier to read than the following-sibling version,
                # but returns a boolean

                # # Alternative 2, harder to read and returns a set of elements, but it is consistent with the self pairs of nodes
                # final_xpath = '{lca_link_path}[{no_lca_no_elem_name}[{elem_n}[@values>={lb1} and @values<={ub1}] and ' \
                #               '( (.//following-sibling::{no_lca_no_elem_name}[{elem_n}[@values>={lb2} and @values<={ub2}]]) ' \
                #               'or (.//preceding-sibling::{no_lca_no_elem_name}[{elem_n}[@values>={lb2} and @values<={ub2}]] ))]]'.format(
                #     lca_link_path=lca_link_path, no_lca_no_elem_name=no_lca_no_elem_name, elem_n=elem_name,
                #     lb1=lower_bound1, ub1=upper_bound1, lb2=lower_bound2, ub2=upper_bound2)

            else:  # self pair with parameters and different ranges, so the normal xpath is fine
                pass

        elif elem1_type == 'boolean' or elem1_type == 'string':
            val1 = re.search('@values="(.+?)"', choice1).group(1)
            val2 = re.search('@values="(.+?)"', choice2).group(1)
            if val1 == val2:  # self with same values
                # final_xpath example : '/root/tax_payer[count(address[country[@values="LU"]] ) >1] '
                final_xpath = 'count({lca_link_path}[count({no_lca_no_elem_name}[{elem_n}[@values="{val1}"]])>1])>0'.format(
                    lca_link_path=lca_link_path, no_lca_no_elem_name=no_lca_no_elem_name, elem_n=elem_name,
                    val1=val1)  # Alternative1, easier to read than the following-sibling version,
                # but returns a boolean

                # Below is alternative2:
                # final_xpath = '{lca_link_path}[{no_lca_no_elem_name}[{elem_n}[@values="{val1}"] and ' \
                #               '( (.//following-sibling::{no_lca_no_elem_name}[{elem_n}[@values="{val2}"]]) ' \
                #               'or (.//preceding-sibling::{no_lca_no_elem_name}[{elem_n}[@values="{val2}"]] ))]]'.format(
                #     lca_link_path=lca_link_path, no_lca_no_elem_name=no_lca_no_elem_name, elem_n=elem_name,
                #     val1=val1, val2=val2)
            else:  # self param with different range, so normal Xpath is fine
                pass
    else:  # the node is not a self, the usual xpath works.
        pass

    # IMPORTANT: every single symbol, e.g., "//" of the xpath expression above is fundamental for it to work properly!
    return final_xpath, sentence_part_name


def substract(a, b):
    return "".join(a.rsplit(b))


def create_partial_xpath(elem_type1, choice_for_re, elem_name, lca_link_path, elem1_path):
    nodes_path_not_in_lca = substract(elem1_path, lca_link_path)  # os.path.relpath() is not good for this
    if nodes_path_not_in_lca != '':  # if elem1_path == lca_link_path, so it is empty
        if nodes_path_not_in_lca[0] == '/':
            nodes_path_not_in_lca = nodes_path_not_in_lca[1:]  # removes first "/", to xpath does not have it
    head_tail = os.path.split(nodes_path_not_in_lca)
    path_not_lca_no_elem = head_tail[0]
    if elem_type1 == 'node' or elem_type1 == 'integer' or elem_type1 == 'real':
        lower_bound1 = re.search('>=(.+?) ', choice_for_re).group(1)
        upper_bound1 = re.search('<=(.+?)]', choice_for_re).group(1)
        if elem_type1 == "node":
            if path_not_lca_no_elem == '':  # just to avoid the issue with [empty[count()]], which is not a valid xpath
                partial_xpath = 'count({elem_n})>={lb} and count({elem_n})<={ub}'.format(elem_n=elem_name,
                                                                                         lb=lower_bound1,
                                                                                         ub=upper_bound1)
            else:
                partial_xpath = '{path_not_lca_no_elem}[count({elem_n})>={lb} and count({elem_n})<={ub}]'.format(
                    path_not_lca_no_elem=path_not_lca_no_elem, elem_n=elem_name, lb=lower_bound1, ub=upper_bound1)

        elif elem_type1 == "integer" or elem_type1 == "real":  # it is a parameter
            partial_xpath = "{}[@values>={} and @values<={}]".format(nodes_path_not_in_lca, lower_bound1, upper_bound1)
        list_for_partial_name = [elem_type1, elem1_path, lower_bound1, upper_bound1]
        partial_name_for_sentence = '_'.join(list_for_partial_name)
    elif elem_type1 == 'boolean' or elem_type1 == 'string':
        # search text inside '@values=" ... "' # The quotes "" in the xpath are necessary for the values of the values,
        # which is not the case for the numbers
        bool_or_string_value1 = re.search('@values="(.+?)"', choice_for_re).group(1)
        # # IMPORTANT string and bool parameter @attributes' values mus have "" around, otherwise xpath will not find them
        # else:
        partial_xpath = '{}[@values="{}"]'.format(nodes_path_not_in_lca, bool_or_string_value1)

        list_for_partial_name = [elem_type1, elem1_path, bool_or_string_value1]
        partial_name_for_sentence = '_'.join(list_for_partial_name)
    else:
        raise ValueError("sentence['og_elem1']['type'] not implemented for partial xpath")
    return partial_xpath, partial_name_for_sentence


def check_sentence(sentence, tree):  # this is not needed anymore, as of framework11.py, but it is here to
    # check in case there are problems/regressions in the future, after modifications
    sentence_is_sat = False  # by default
    # The idea is to have choice1 AND choice2 AND wanted_LCA_path, where wanted_LCA_path is the
    # path of the LCA that we have selected, so it can be at a different depth, like /root, /root/row, /root/row/crop ..
    # Here I build the xpath expression to find if the LCA of choice1 and choice2 is == to wanted_LCA_path.
    # e.g. if the lca is /root/row, but the lca that I find in the testcase is /root, the sentence is not satisfied.
    final_xpath = sentence['link_xpath']  # obtained with create_xpath_for_link(sentence)

    # 4) query the tree with the LCA xpath
    candidate_elems = check_xpath_expr(final_xpath,
                                       tree)  # candidate is in form {'name': 'row', 'instance': '0', 'type': 'node', 'nb_instances': '2', 'path': '/root/row[1]'}
    # 5) check if the lca path is ==  wanted_LCA_path

    if isinstance(candidate_elems, bool):  # this is here because with this formalization some results are
        # bool and some are a set of elements.
        if candidate_elems:
            sentence_is_sat = True
        else:
            sentence_is_sat = False
        return sentence_is_sat
    else:
        for candidate in candidate_elems:
            # print("candidate['path'] = " + candidate['path'] + " sentence['link'] " + sentence['link'])
            candidate_lca_path = re.sub('\[.*?\]', '', candidate['path'])
            if candidate_lca_path == sentence['link']:
                sentence_is_sat = True
    return sentence_is_sat  # , candidate_elems


def remove_sentences_of_indexes(sentences, indexes_list, sat_sentences):
    # remove sat sentences from sentences and add them to sat_sentences
    cpt = 0  # counts the distance between the indexes of the two lists
    i = 0
    n = len(sentences)
    while i < n:
        if i + cpt in indexes_list:
            sentences[i]['satisfied'] = True
            sat_sentences.append(sentences.pop(i))
            cpt += 1
            n -= 1
        else:
            i += 1
    return sentences  # not really needed, as it is passed by reference


def check_sentences_of_tc_i(sentences, num_sat_sentences, indexes_sat_sentences, i, inst_trees, index_i):
    inst_testcase_path_i = "../experiment/test_case_{}/test_case_{}.test_case".format(i, i)
    inst_tree_i = etree.parse(inst_testcase_path_i)
    inst_root_i = inst_tree_i.getroot()

    convert_TAF_tmplt_to_std_xml(inst_root_i, False)  # false because it is the TC
    # removed the inst_trees.append(inst_tree_i) to not have issues with pickling lxml elements with multiprocessing manager
    inst_trees.append(inst_tree_i)  # NOTE: this append() has to be done after the conversion
    # convert_TAF_tmplt_to_std_xml, otherwise it will not work, and it will return a root and not a tree

    """6) Parse the converted Test_Case_"i" (or the k TCs) and check which sentences are covered.
            If they are covered, change to 'satisfied' = True.
            If not covered, change to 'satisfied' = unsat.
        6.1) If option to generate k test cases, select the one that covers the most sentences."""

    print("\n Checking sentences in template num =", index_i)

    ii = 0
    n = len(sentences)
    with tqdm(total=n) as prog_bar:
        print("\nsentences[0] =", sentences[ii])
        while ii < n:  # to count the sat sentences for each of the K test cases
            sentence_is_satisfied = check_sentence(sentences[ii], inst_tree_i)
            if sentence_is_satisfied:
                num_sat_sentences[i] += 1  # it is "i" and not "ii", because "i" is for the k test cases
                indexes_sat_sentences[i].append(ii)
            ii += 1
            prog_bar.update(1)


def check_sat_sentences_in_k_testcases(sentences, index_i, num_test_cases_to_create_per_combination):
    num_of_sat_sentences = [0 for i in range(num_test_cases_to_create_per_combination)]
    # print("num_of_sat_sentences =", num_of_sat_sentences)
    indexes_of_sat_sentences_in_k_tcs = [[] for i in range(num_test_cases_to_create_per_combination)]
    inst_trees = []  # contains the k instantiated trees of the k test cases created by TAF
    for i_tc in range(num_test_cases_to_create_per_combination):
        print("num_of_sentences_remaining_still_to_check =", len(sentences))
        check_sentences_of_tc_i(sentences, num_of_sat_sentences, indexes_of_sat_sentences_in_k_tcs, i_tc,
                                inst_trees, index_i)
    id_max_sat_sentences = num_of_sat_sentences.index(max(num_of_sat_sentences))
    print("indexes_of_sat_sentences_in_k_tcs =", indexes_of_sat_sentences_in_k_tcs)

    print("num_of_sat_sentences =", num_of_sat_sentences)
    print("id_max_sat_sentences =", id_max_sat_sentences)

    print("len(indexes_of_sat_sentences_in_k_tcs[id_max_sat_sentences]) =",
          len(indexes_of_sat_sentences_in_k_tcs[id_max_sat_sentences]))

    return id_max_sat_sentences, indexes_of_sat_sentences_in_k_tcs


def generate_taf_constraints_and_xpath_for_link(sentences, root_name, unguided):
    print("\n \n \n  =========================")
    for i_i, sentence in enumerate(sentences):
        sentence['index'] = i_i  # some indexes will not be present after the filtering of the impossible sentences
        if unguided:
            sentence['constraint'] = ''
            sentence['constr_tree_elem'] = ''  # for the strategy in which we compare unguided to selecting the choices
        else:
            # framework 12, create two constraints elems to add to the TAF template, so TAF is faster at finding a solution.
            # this is here to have first the constriants of the two choices in the temlate, so TAF will have an easier life.
            index_for_constr_name = 0
            constraints_tree_elements = []
            constraints_list = []
            for choice_num in [1,
                               2]:
                constr_string, constr_choice = create_single_constraint_from_choice(sentence, i_i, root_name,
                                                                                    str(choice_num))
                constraints_tree_elements.append(constr_choice)
                constraints_list.append(constr_string)
                index_for_constr_name += 1

            constraint_in_text_form, sentence_taf_constr_tree_elem = generate_taf_constraint(sentence, i_i, root_name)
            constraints_tree_elements.append(sentence_taf_constr_tree_elem)
            constraints_list.append(constraint_in_text_form)
            sentence[
                'constr_tree_elem'] = constraints_tree_elements  # here there should be 3 tree elements, two constrinits for two single choices, and one for the sentence
            sentence['constraint'] = constraints_list
        sentence['link_xpath'], sentence_name = create_xpath_for_link(
            sentence)  # add the xpath for the lca/link, to check if it
        # corresponds to the TAF constraint
        sentence_name = sentence_name + '--' + sentence['link']
        sentence[
            'sentence_name'] = sentence_name
    return sentences


def create_list_elem_with_path(abstract_template_path):
    converted_abstract_tree = etree.parse(abstract_template_path)  # create a copy that will be modified
    converted_abstract_root = converted_abstract_tree.getroot()
    convert_TAF_tmplt_to_std_xml(converted_abstract_root,
                                 True)  # True because I am converting the template, otherwise it is the TC
    template_elems_path_and_nb_instances = []  # to store paths and multiplicity of the elements of original template
    print("converted tree paths = \n")
    for e in converted_abstract_root.iter():  # equivalent to:  # for e in root.iter():
        # IMPORTANT lxml will always give the path with /root/, no matter the root name! So the root name has always to be "root" !!
        if e.tag != 'constraint':  # to avoid adding constraints,

            if e.tag == 'root' and e.attrib['name'] != 'root':
                # a fix for when the root has a different name than root, which creates issues
                print(f"{bcolors.WARNING}\n root.tag and root name must be the same == root \n{bcolors.ENDC}")
                e.attrib['name'] = 'root'
            e.attrib['path'] = converted_abstract_tree.getpath(e)
            # template_elems_path_and_nb_instances.append({'element': e, 'path': converted_abstract_tree.getpath(e), 'nb_instances': e['']})
            template_elems_path_and_nb_instances.append(e.attrib)
        print(converted_abstract_tree.getpath(e))
    root_name = converted_abstract_root.attrib['name']
    print("=====================")

    return template_elems_path_and_nb_instances, root_name, converted_abstract_root, converted_abstract_tree


def create_list_of_choices(template_elems_path_and_nb_instances, root_name, num_of_partitions):
    selection_dict = {  # dict containing the names of the functions to call to transform elements into xpath
        # expressions with each partition
        'node': create_xpath_for_float,  # create_xpath_for_integer_or_node,  # same as float
        'boolean': create_xpath_for_boolean,
        'integer': create_xpath_for_float,  # create_xpath_for_integer_or_node,
        'real': create_xpath_for_float,
        'string': create_xpath_for_boolean,  # it works like for the boolean,
    }

    new_list_single_choices = []
    for elem in template_elems_path_and_nb_instances:
        if elem['name'] != root_name and elem[
            'name'] != 'seed':  # 'seed' should never appear in a template, just in the TCs
            print('tree elem = ', elem)
            if elem['type'] == 'boolean':  # a fix for when boolean does not have the attrib "values"="True;False"
                elem['values'] = 'True;False'

            new_xpath_exprs = selection_dict[elem['type']](og_element=elem, num_partitions=num_of_partitions,
                                                           elem_type=elem['type'])
            for new_xpath_expr in new_xpath_exprs:
                if elem['type'] == 'node':
                    if 'max' in elem:
                        elem_max = elem['max']
                    elif 'nb_instances' in elem:
                        elem_max = elem['nb_instances']
                    new_list_single_choices.append({'xpath_expr': new_xpath_expr, 'elem': elem,
                                                    'nb_instances': elem_max})
                else:  # it is a parameter, so we do not assign a nb_instances, even if TAf could manage it
                    new_list_single_choices.append(
                        {'xpath_expr': new_xpath_expr, 'elem': elem, 'nb_instances': '1'})

    print("=================")
    return new_list_single_choices


def create_sentences_from_list_of_choices(new_list_single_choices):
    print("\n \n \n  =========================")
    sentences = []  # list of sentences,
    # The link inside "sentences" is the name of the LCA from the template, not from the TC, since the LCA could be
    # different, e.g. /filed/row/crop, and two crops have row as LCA in the template, but in the TC, they could
    # have field as LCA, since they could be from a different row[]
    sentences_with_issues = []  # it was just created to check and debug when there are issues

    sentence_type = 'pair'
    for idx, choice1 in enumerate(new_list_single_choices):  # generate the "sentences" list with dicts
        for choice2 in new_list_single_choices[idx:]:  # to not have overlapping ranges, put [idx + 1:]
            new_sentence = {'index': '', 'sentence_name': '', 'link_xpath': '',
                            'choice1': choice1['xpath_expr'], 'elem1_path': choice1['elem']['path'],
                            'nb_inst_elem1': choice1['nb_instances'], 'elem_satisf_choice1': '',
                            'og_elem1': choice1['elem'],
                            'choice2': choice2['xpath_expr'], 'elem2_path': choice2['elem']['path'],
                            'nb_inst_elem2': choice2['nb_instances'], 'elem_satisf_choice2': '',
                            'og_elem2': choice2['elem'],
                            'link': '', 'satisfied': False, 'test_cases': '', 'constraint': '',
                            'constr_tree_elem': '', 'xpath_elem_where_to_add_constr': '', 'type': sentence_type,
                            'is_self': ''}

            lca_name_in_template = find_LCA_path(choice1['elem']['path'], choice2['elem']['path'])

            length1 = len(choice1['elem']['path'].split('/'))  # the split() gives an empty '' at the beginning
            length2 = len(choice2['elem']['path'].split('/'))

            if choice1['elem']['path'] == choice2['elem']['path']:
                new_sentence['is_self'] = True
            else:
                new_sentence['is_self'] = False
            if length1 <= 3 and length2 <= 3 and choice1['elem']['path'] == choice2['elem']['path']:
                # something like /root/tax_payer and /root/tax_payer. or /root/paramA and /root/paramA
                # length <=3 because the split('/') gives an empty '' at the beginning
                # this is a self pair that is not feasible /r/A and /r/A.
                # While /root/nodeA and /root/nodeB would be feasible
                sentences_with_issues.append(new_sentence)
            elif length1 > 3 and length2 > 3:
                if choice1['elem']['path'] == choice2['elem']['path']:
                    # cases: /root/taxp/nodeA and /root/taxp/nodeA or paramA and paramA
                    lca_name_in_template = '/'.join(lca_name_in_template.split('/')[:-2])  # it has to be at
                elif choice1['elem']['path'] != choice2['elem']['path']:
                    if choice1['elem']['path'] in choice2['elem']['path'] or choice2['elem']['path'] in choice1['elem'][
                        'path']:
                        # if /r/A/B is in /r/A/B/parA, like choice 1 and choice2
                        lca_name_in_template = '/'.join(lca_name_in_template.split('/')[:-1])
                new_sentence['link'] = lca_name_in_template
                sentences.append(new_sentence)
            elif (length1 == 3 or length2 == 3) and choice1['elem']['path'] != choice2['elem']['path']:
                # case # if /r/A is in /r/A/parA, like choice 1 and choice2
                if choice1['elem']['path'] in choice2['elem']['path'] or choice2['elem']['path'] in choice1['elem'][
                    'path']:
                    # if /r/A is in /r/A/parA, like choice 1 and choice2
                    lca_name_in_template = '/'.join(lca_name_in_template.split('/')[:-1])
                    new_sentence['link'] = lca_name_in_template
                    sentences.append(new_sentence)
            else:  # the other cases should be managed without issues
                print("choice1['elem']['path'] =", choice1['elem']['path'])
                print("choice2['elem']['path'] =", choice2['elem']['path'])
                print("choice2['elem']['path'].split('/') =", choice2['elem']['path'].split('/'))
                new_sentence['link'] = lca_name_in_template
                sentences.append(new_sentence)
                # raise ValueError("issue while creating choices")
            # How to change TAF timeout? it is not z3 timeout in settings.xml. Error is:
            # ERROR -> Generator::generate() -> unable to generate the current template
            # in Generator.py:103:
    return sentences, sentences_with_issues


def remove_unsat_sentence(sentences, index_i, unsat_sentences, exper_start_time, target_template_path):
    sentences[0]['satisfied'] = 'unsat'
    sentences[0]['unsat_index'] = index_i
    unsat_sentences.append(sentences.pop(0))  # put the unsat sentence in the unsat list

    target_unsat_backup_folder = r'../../experiment_results/' + str(which_k_folder) + '/' + str(
        exper_start_time) + '/unsat_templates/'
    create_dir(target_unsat_backup_folder)
    move_folder(target_template_path, target_unsat_backup_folder)


def clean_previous_exp_files_and_folders(exp_dir):
    rm_folder_content(exp_dir)  # empty folders of previous experiment
    create_dir(exp_dir)
    rm_folder_content("../templates/pairwise/")
    create_dir("../templates/pairwise/")


def write_template_with_new_constraint(sentence, tree_, add_to_root, target_template_path, unguided):
    tree = copy.deepcopy(tree_)
    root = tree.getroot()
    # constraint_to_add = sentence['constraint']  # used to write directly to the string
    constraint_tree_elem_to_add = sentence['constr_tree_elem']
    xpath_elem_where_to_add_constr = sentence['xpath_elem_where_to_add_constr']
    if unguided:
        pass  # do nothing, do not add constraint to root, as we want to compare the differences
    else:
        if add_to_root:
            for constr in constraint_tree_elem_to_add:
                root.append(constr)
            # root.append(constraint_tree_elem_to_add)  #this was the previous implementation, from framework11
        else:
            where_to_append = tree.find(xpath_elem_where_to_add_constr)
            where_to_append.append(constraint_tree_elem_to_add)
    etree.indent(root, space="    ")
    etree.indent(root, space="\t")
    # etree.dump(root)  # for debugging
    tree.write(target_template_path, encoding='utf8', xml_declaration=True, pretty_print=True)


def mv_tc_to_backup_folder(index_i, exper_start_time, id_max_sat_sentences, exp_dir, target_template_path,
                           which_k_folder):
    target_backup_folder = r'../../experiment_results/' + str(which_k_folder) + '/' + str(
        exper_start_time) + '/test_case_' + str(index_i)
    the_right_tc_dir = exp_dir + '/test_case_' + str(id_max_sat_sentences)
    move_folder(the_right_tc_dir, target_backup_folder)  # move_taf_experiment_folders
    move_folder(exp_dir + '/time', target_backup_folder)  # time is the file of how long TAF needed to generate a tc.
    # In case of multiple test cases, it appends the times
    rm_folder_content(exp_dir)  # to remove the k-1 test cases that satisfied fewer sentences
    create_dir(exp_dir)
    move_folder(target_template_path, target_backup_folder)  # move the template too


def add_manual_sentences_to_tax_payer():
    # man_sentences_to_add_dnf_form = ['child[i]\disability_rate EQ 0 OR NOT(child[i]\disability_type EQ None)',
    #                         'child[i]\disability_type EQ None OR NOT(child[i]\disability_rate EQ 0)',
    #                         'tax_payer[i]\income_pension.nb_instances + tax_payer[i]\income_employment.nb_instances + tax_payer[i]\income_other.nb_instances <= 3',
    #                         'tax_payer[i]\income_pension.nb_instances + tax_payer[i]\income_employment.nb_instances + tax_payer[i]\income_other.nb_instances >= 0',
    #                         'tax_payer[i]\disability_rate EQ 0 OR NOT(tax_payer[i]\disability_type EQ None)',
    #                         'tax_payer[i]\disability_type EQ None OR NOT(tax_payer[i]\disability_rate EQ 0)',
    #                         'tax_payer[i]\is_resident EQ True OR NOT(tax_payer[i]ddress[j]\country EQ LU)',
    #                         'tax_payer[i]ddress[k]\country EQ LU OR tax_payer[i]\is_resident EQ False OR NOT(tax_payer[i]\income_pension[j]\is_local EQ True)']

    # each one has to be attached below the corresponding <constraint> node
    # man_sentences_to_add_from_dnf_to_single_properties = ['child[i]\disability_rate EQ 0',  # c2a
    #                         'NOT(child[i]\disability_type EQ None)',  # c2a
    #
    #                         'child[i]\disability_type EQ None',  # c2a
    #                         'NOT(child[i]\disability_rate EQ 0)',  # c2a
    #                         # 'tax_payer[i]\income_pension.nb_instances + tax_payer[i]\income_employment.nb_instances + tax_payer[i]\income_other.nb_instances <= 3',
    #                         # 'tax_payer[i]\income_pension.nb_instances + tax_payer[i]\income_employment.nb_instances + tax_payer[i]\income_other.nb_instances >= 0',
    #
    #                         'tax_payer[i]\disability_rate EQ 0',  # c2
    #                         'NOT(tax_payer[i]\disability_type EQ None)',  # c2
    #
    #                         'tax_payer[i]\disability_type EQ None',  # c2
    #                         'NOT(tax_payer[i]\disability_rate EQ 0)',  # c2
    #
    #                         'tax_payer[i]\is_resident EQ True',  # c3
    #                         'NOT(tax_payer[i]\address[j]\country EQ LU)',  # c3
    #
    #                         'tax_payer[i]\address[k]\country EQ LU',  # c4_pension # c4_employment # c4_other
    #                         'tax_payer[i]\is_resident EQ False',  # c4_pension # c4_employment # c4_other
    #                         'NOT(tax_payer[i]\income_pension[j]\is_local EQ True)'
    #                         # c4_pension # c4_employment # c4_other
    #                         ]
    new_sent = []
    sentence_type = 'manual'
    # c2a_1
    new_sent.append(
        {'index': 10001, 'sentence_name': 'c2a_1',
         'link_xpath': '/placeholder',  # ./placeholder to avoid XPATH finding something and satisfying the predicate,
         # as we want to use TAF to check if the partially/fully instantiated test case is satisfying the constraints
         'link': '/root/tax_payer/child/disability_rate',
         'constraint': '<constraint name="c2a_1" types="exist" \n\t '
                       'expressions="child[i]\\disability_rate EQ 0" \n\t '
                       'quantifiers="i" \n\t '
                       'ranges="[0, child.nb_instances-1]" /> \n',
         'satisfied': False, 'test_cases': '', 'constr_tree_elem': '',
         'xpath_elem_where_to_add_constr': './/*[@name="child"]', 'type': sentence_type, 'is_self': False})
    # c2a_2
    new_sent.append({'index': 10002, 'sentence_name': 'c2a_2',
                     'link_xpath': '/placeholder',
                     'link': '/root/tax_payer/child/disability_type',
                     'constraint': '<constraint name="c2a_2" types="exist" \n\t '
                                   'expressions="NOT(child[i]\\disability_type EQ None)" \n\t '
                                   'quantifiers="i" \n\t '
                                   'ranges="[0, child.nb_instances-1]" /> \n',
                     'satisfied': False, 'test_cases': '', 'constr_tree_elem': '',
                     'xpath_elem_where_to_add_constr': './/*[@name="child"]', 'type': sentence_type, 'is_self': False})
    # c2a_3
    new_sent.append({'index': 10003, 'sentence_name': 'c2a_3',
                     'link_xpath': '/placeholder',
                     'link': '/root/tax_payer/child/disability_type',
                     'constraint': '<constraint name="c2a_3" types="exist" \n\t '
                                   'expressions="child[i]\\disability_type EQ None" \n\t '
                                   'quantifiers="i" \n\t '
                                   'ranges="[0, child.nb_instances-1]" /> \n',
                     'satisfied': False, 'test_cases': '', 'constr_tree_elem': '',
                     'xpath_elem_where_to_add_constr': './/*[@name="child"]', 'type': sentence_type, 'is_self': False})
    # c2a_4
    new_sent.append(
        {'index': 10004, 'sentence_name': 'c2a_4',
         'link_xpath': '/placeholder',
         'link': '/root/tax_payer/child/disability_rate',
         'constraint': '<constraint name="c2a_4" types="exist" \n\t '
                       'expressions="NOT(child[i]\\disability_rate EQ 0)" \n\t '
                       'quantifiers="i" \n\t '
                       'ranges="[0, child.nb_instances-1]" /> \n',

         'satisfied': False, 'test_cases': '', 'constr_tree_elem': '',
         'xpath_elem_where_to_add_constr': './/*[@name="child"]', 'type': sentence_type, 'is_self': False})
    # c2_1
    new_sent.append(
        {'index': 10005, 'sentence_name': 'c2_1',
         'link_xpath': '/placeholder',
         'link': '/root/tax_payer/disability_rate',
         'constraint': '<constraint name="c2_1" types="exist" \n\t '
                       'expressions="tax_payer[i]\\disability_rate EQ 0" \n\t '
                       'quantifiers="i" \n\t '
                       'ranges="[0, tax_payer.nb_instances-1]" /> \n',

         'satisfied': False, 'test_cases': '', 'constr_tree_elem': '',
         'xpath_elem_where_to_add_constr': './/*[@name="tax_payer"]', 'type': sentence_type, 'is_self': False})
    # c2_2
    new_sent.append(
        {'index': 10006, 'sentence_name': 'c2_2',
         'link_xpath': '/placeholder',
         'link': '/root/tax_payer/disability_type',
         'constraint': '<constraint name="c2_2" types="exist" \n\t '
                       'expressions="NOT(tax_payer[i]\\disability_type EQ None)" \n\t '
                       'quantifiers="i" \n\t '
                       'ranges="[0, tax_payer.nb_instances-1]" /> \n',
         'satisfied': False, 'test_cases': '', 'constr_tree_elem': '',
         'xpath_elem_where_to_add_constr': './/*[@name="tax_payer"]', 'type': sentence_type, 'is_self': False})
    # c2_3
    new_sent.append(
        {'index': 10007, 'sentence_name': 'c2_3',
         'link_xpath': '/placeholder',
         'link': '/root/tax_payer/disability_type',
         'constraint': '<constraint name="c2_3" types="exist" \n\t '
                       'expressions="tax_payer[i]\\disability_type EQ None" \n\t '
                       'quantifiers="i" \n\t '
                       'ranges="[0, tax_payer.nb_instances-1]" /> \n',
         'satisfied': False, 'test_cases': '', 'constr_tree_elem': '',
         'xpath_elem_where_to_add_constr': './/*[@name="tax_payer"]', 'type': sentence_type, 'is_self': False})
    # c2_4
    new_sent.append(
        {'index': 10008, 'sentence_name': 'c2_4',
         'link_xpath': '/placeholder',
         'link': '/root/tax_payer/disability_rate',
         'constraint': '<constraint name="c2_4" types="exist" \n\t '
                       'expressions="NOT(tax_payer[i]\\disability_rate EQ 0)" \n\t '
                       'quantifiers="i" \n\t '
                       'ranges="[0, tax_payer.nb_instances-1]" /> \n',
         'satisfied': False, 'test_cases': '', 'constr_tree_elem': '',
         'xpath_elem_where_to_add_constr': './/*[@name="tax_payer"]', 'type': sentence_type, 'is_self': False})
    # c3_1
    new_sent.append(
        {'index': 10009, 'sentence_name': 'c3_1',
         'link_xpath': '/placeholder',
         'link': '/root/tax_payer/is_resident',
         'constraint': '<constraint name="c3_1" types="exist" \n\t '
                       'expressions="tax_payer[i]\\is_resident EQ True" \n\t '
                       'quantifiers="i" \n\t '
                       'ranges="[0, tax_payer.nb_instances-1]" /> \n',
         'satisfied': False, 'test_cases': '', 'constr_tree_elem': '',
         'xpath_elem_where_to_add_constr': './/*[@name="tax_payer"]', 'type': sentence_type, 'is_self': False})
    # c3_2
    new_sent.append(
        {'index': 10010, 'sentence_name': 'c3_2',
         'link_xpath': '/placeholder',
         'link': '/root/tax_payer/address/country',
         'constraint': '<constraint name="c3_2" types="exist;exist" \n\t '
                       'expressions="NOT(tax_payer[i]\\address[j]\\country EQ LU)" \n\t '
                       'quantifiers="i;j" \n\t '
                       'ranges="[0, tax_payer.nb_instances-1];[0, tax_payer[i]\\address.nb_instances-1]" /> \n',
         'satisfied': False, 'test_cases': '', 'constr_tree_elem': '',
         'xpath_elem_where_to_add_constr': './/*[@name="tax_payer"]', 'type': sentence_type, 'is_self': False})
    # c4_pension_1 # c4_employment # c4_other
    new_sent.append(
        {'index': 10011, 'sentence_name': 'c4_pension_1',
         'link_xpath': '/placeholder',
         'link': '/root/tax_payer/address/country',
         'constraint': '<constraint name="c4_pension_1" types="exist;exist" \n\t '
                       'expressions="tax_payer[i]\\address[k]\\country EQ LU" \n\t '
                       'quantifiers="i;k" \n\t '
                       'ranges="[0, tax_payer.nb_instances-1];[0, tax_payer[i]\\address.nb_instances-1]" /> \n',
         'satisfied': False, 'test_cases': '', 'constr_tree_elem': '',
         'xpath_elem_where_to_add_constr': './/*[@name="tax_payer"]', 'type': sentence_type, 'is_self': False})
    # c4_pension_2 # c4_employment # c4_other
    new_sent.append(
        {'index': 10012, 'sentence_name': 'c4_pension_2',
         'link_xpath': '/placeholder',
         'link': '/root/tax_payer/is_resident',
         'constraint': '<constraint name="c4_pension_2" types="exist" \n\t '
                       'expressions="tax_payer[i]\\is_resident EQ False" \n\t '
                       'quantifiers="i" \n\t '
                       'ranges="[0, tax_payer.nb_instances-1]" /> \n',
         'satisfied': False, 'test_cases': '', 'constr_tree_elem': '',
         'xpath_elem_where_to_add_constr': './/*[@name="tax_payer"]', 'type': sentence_type, 'is_self': False})
    # c4_pension_3 # c4_employment # c4_other
    new_sent.append({'index': 10013, 'sentence_name': 'c4_pension_3',
                     'link_xpath': '/placeholder',
                     'link': '/root/tax_payer/income_pension/is_local',
                     'constraint': '<constraint name="c4_pension_3" types="exist;exist" \n\t '
                                   'expressions="NOT(tax_payer[i]\\income_pension[j]\\is_local EQ True)" \n\t '
                                   'quantifiers="i;j" \n\t '
                                   'ranges="[0, tax_payer.nb_instances-1];[0, tax_payer[i]\income_pension.nb_instances-1]" /> \n',
                     'satisfied': False, 'test_cases': '', 'constr_tree_elem': '',
                     'xpath_elem_where_to_add_constr': './/*[@name="tax_payer"]', 'type': sentence_type,
                     'is_self': False})

    new_sent = convert_manual_sentences_to_tree_elem_constraints(new_sent)
    return new_sent


def add_manual_sentences_to_oz():
    # DNF: .\is_first_track_outer EQ True OR NOT(..\field\row.nb_instances EQ 1)
    new_sent = []
    sentence_type = 'manual'
    # first_track_1
    new_sent.append(
        {'index': 20001, 'sentence_name': 'c2a_1',
         'link_xpath': '/placeholder',  # ./placeholder to avoid XPATH finding something and satisfying the predicate,
         # as we want to use TAF to check if the partially/fully instantiated test case is satisfying the constraints
         'link': '/root/mission/is_first_track_outer',
         'constraint': '<constraint name="first_track_1"  \n\t '
                       'expressions=".\is_first_track_outer EQ True" \n\t '
                       '/> \n',
         'satisfied': False, 'test_cases': '', 'constr_tree_elem': '',
         'xpath_elem_where_to_add_constr': './/*[@name="mission"]', 'type': sentence_type, 'is_self': False})
    # first_track_2
    new_sent.append({'index': 20002, 'sentence_name': 'first_track_2',
                     'link_xpath': '/placeholder',
                     'link': '/root/field',
                     'constraint': '<constraint name="c2a_2"  \n\t '
                                   'expressions="NOT(..\\field\\row.nb_instances EQ 1)" \n\t '
                                   '/> \n',
                     'satisfied': False, 'test_cases': '', 'constr_tree_elem': '',
                     'xpath_elem_where_to_add_constr': './/*[@name="row"]', 'type': sentence_type, 'is_self': False})

    new_sent = convert_manual_sentences_to_tree_elem_constraints(new_sent)
    return new_sent


def add_manual_sentences():  # the path is hardcoded, do not change it
    manually_added_xpath_sentences = []  # in the form of {'': '' .....}
    if abstract_template_path == '../templates/taxPayerExample/tax_payer_upd.template':  # _upd has root with name=root and not name=test_case, otherwise there are issues.
        # //{}[position()=1]
        # same_num_children ': lambda d: '//{}/@nb_instances  use count() and it has to be for all the children. so the tree is the same at that level
        new_taxpayer_sentences = add_manual_sentences_to_tax_payer()
        for elem in new_taxpayer_sentences:
            manually_added_xpath_sentences.append(elem)
    elif abstract_template_path == '../templates/ozExample/oz_upd.template':  # _upd has root with name=root and not name=test_case, otherwise there are issues.
        new_oz_sentences = add_manual_sentences_to_oz()
        for elem in new_oz_sentences:
            manually_added_xpath_sentences.append(elem)
    return manually_added_xpath_sentences


def convert_manual_sentences_to_tree_elem_constraints(new_sent):
    for man_sent in new_sent:  # create constraint tree element from the constraint string
        constr_name = re.findall(r'name="(.*?)"', man_sent['constraint'])[
            0]  # [0] because it gives back a list ['match']
        expressions_str = re.findall(r'expressions="(.*?)"', man_sent['constraint'])[0]
        if 'quantifiers=' in man_sent['constraint']:  # constraint with quntifiers
            types_str = re.findall(r'types="(.*?)"', man_sent['constraint'])[0]
            quantifiers_str = re.findall(r'quantifiers="(.*?)"', man_sent['constraint'])[0]
            ranges_str = re.findall(r'ranges="(.*?)"', man_sent['constraint'])[0]
            man_sent['constr_tree_elem'] = etree.Element('constraint', {'name': constr_name, 'types': types_str,
                                                                        'expressions': expressions_str,
                                                                        'quantifiers': quantifiers_str,
                                                                        'ranges': ranges_str})  # tree elem has to be a dictionary
        else:  # simpler constraints without quantifiers, because they are not needed
            # types_str = ''
            # quantifiers_str = ''
            # ranges_str = ''
            man_sent['constr_tree_elem'] = etree.Element('constraint', {'name': constr_name,
                                                                        'expressions': expressions_str})  # tree elem has to be a dictionary

        # could be also done like this, assigning types_str = '', but it is nice to see a cleaner constraints when there are no quantifiers
        # man_sent['constr_tree_elem'] = etree.Element('constraint', {'name': constr_name, 'types': types_str,
        #                                                             'expressions': expressions_str,
        #                                                             'quantifiers': quantifiers_str,
        #                                                             'ranges': ranges_str})  # tree elem has to be a dictionary
        man_sent['link_xpath'] = convert_taf_expressions_to_xpath(expressions_str)
    return new_sent


def convert_taf_expressions_to_xpath(expressions_str):
    # The proper way to code this is with a parse, use the TAF parser
    if ";" in expressions_str:
        print(f"{bcolors.WARNING}\n Exception ERROR. there are two expressions, "
              f"but there should be just one! \n{bcolors.ENDC}")
    # hardcoded and just for the tax_payer and oz cases.
    xpath_str = ''  # just to have something, maybe put something not valid, so if the algorithm does not generate it,
    # XPATH will throw an error?
    expression = re.sub('\\\.*?', '/', expressions_str)  # to escape one \, use \\\
    expression = re.sub('\[.*?\]', '', expression)
    if 'NOT' in expression:
        expression = re.sub(r'NOT\(', '', expression)
        expression = re.sub(r'\)', '', expression)  # remove the last ")"
        if 'EQ' in expression:
            # add case in which first part and second part are both paths
            first_part, second_part = expression.split(" EQ ")
            if '/' in first_part:  # this can be a "\\" if the conversion from TAF expressions that use "\" is done later, and not at the beginning
                has_nb_instances = '.nb_instances' in first_part
                first_part = re.sub(r'\.\./', '', first_part)
                first_part = re.sub(r'\./', '', first_part)
                if has_nb_instances and is_float(second_part):
                    first_part = re.sub(r'.nb_instances', '', first_part)
                    if len(first_part.rsplit('/')) >= 2 and first_part.split('/') != '':
                        first_part_path = first_part.rpartition('/')[0]
                        first_part_last_elem = first_part.rpartition('/')[2]  # because '/' is the rpartition('/')[1]
                        xpath_str = '//{}[count({})!={}]'.format(first_part_path, first_part_last_elem, second_part)

                elif not has_nb_instances and is_float(second_part):
                    xpath_str = '//{}[@values!={}]'.format(first_part, second_part)
                else:
                    xpath_str = '//{}[@values!="{}"]'.format(first_part, second_part)

    elif 'AND' in expression:  # AND(.., ..)
        expression = re.sub(r'AND\(', '', expression)
        expression = re.sub(r'\)', '', expression)  # remove the last ")"
        # split
        # first_part, second_part = expression.split("'")
    else:  # there are no AND or NOT
        if 'EQ' in expression:
            # add case in which first part and second part are both paths
            first_part, second_part = expression.split(" EQ ")
            if '/' in first_part:  # this can be a "\\" if the conversion from TAF expressions that use "\" is done later, and not at the beginning
                has_nb_instances = '.nb_instances' in first_part
                first_part = re.sub(r'\.\./', '', first_part)
                first_part = re.sub(r'\./', '', first_part)
                if has_nb_instances and is_float(second_part):
                    first_part = re.sub(r'.nb_instances', '', first_part)
                    if len(first_part.rsplit('/')) >= 2 and first_part.split('/') != '':
                        first_part_path = first_part.rpartition('/')[0]
                        first_part_last_elem = first_part.rpartition('/')[
                            2]  # because '/' is the rpartition('/')[1]
                        xpath_str = '//{}[count({})!={}]'.format(first_part_path, first_part_last_elem, second_part)

                if is_float(second_part):
                    xpath_str = '//{}[@values={}]'.format(first_part, second_part)
                else:
                    xpath_str = '//{}[@values="{}"]'.format(first_part, second_part)
    # remember to add dot "." to the xpath "//"
    return xpath_str


def append_constraint_to_tree_node(tree, sentence):
    xpath_elem_where_to_add_constr = sentence['xpath_elem_where_to_add_constr']
    constr_to_append = sentence['constr_tree_elem']
    root = tree.getroot()
    where_to_append = root.find(
        xpath_elem_where_to_add_constr)  # xpath_elem_where_to_add_constr = './/*[@name="child"]'
    # constr_to_append comes from the sentence['constr_tree_elem'], which has been calculated before in add_manual_sentences_to_tax_payer()
    where_to_append.append(constr_to_append)
    print("===============\n")
    etree.indent(root, space="    ")
    etree.indent(root, space="\t")
    etree.dump(root)


def write_experiment_info_to_file(exper_start_cpu_time, exper_start_time, ab_template_path, sat_sentences,
                                  unsat_sentences, filtered_sentences_, sorted_sat_sentences, num_of_test_cases,
                                  total_num_sentences, num_testcases_to_create_per_combination, num_unsat_sentences):
    exper_end_time = int(time.time())  # int() is to truncate decimals
    exper_end_cpu_time = float(time.process_time())
    total_cpu_time = str(exper_end_cpu_time - exper_start_cpu_time)
    total_exp_time = str(int(exper_end_time) - int(exper_start_time))
    datetime_exper_start_time = str(datetime.fromtimestamp(exper_start_time))
    datetime_exper_end_time = str(datetime.fromtimestamp(exper_end_time))
    num_filtered_sentences = len(filtered_sentences_)

    with open(r'../../experiment_results/' + str(which_k_folder) + '/' + str(exper_start_time) + '/experiment_info.txt',
              'w') as doc:  # because elemTree.write() doesn't work
        doc.write('exper_start_time =' + str(exper_start_time) + '\n')
        doc.write('Original template name =' + ab_template_path + '\n')
        doc.write('Experiment start time =' + datetime_exper_start_time + '\n')
        doc.write('Experiment end time =' + datetime_exper_end_time + '\n')
        doc.write('Total experiment time =' + total_exp_time + ' s \n')
        doc.write('Total CPU time =' + total_cpu_time + '\n')
        doc.write('Num_test_cases =' + str(num_of_test_cases) + '\n')
        doc.write('total_num_sentences =' + str(total_num_sentences) + '\n')
        doc.write('num_testcases_to_create_per_combination =' + str(num_testcases_to_create_per_combination) + '\n')
        doc.write('num_filtered_sentences =' + str(num_filtered_sentences) + '\n')
        doc.write('num_unsat_sentences =' + str(num_unsat_sentences))

        doc.write('\n\n\n================================== \n\n\n')
        for sentence in sat_sentences:
            doc.write(str(sentence) + '\n')
        doc.write('\n\n\n================================== \n\n\n')
        doc.write('unsat_sentences = \n')
        for sentence in unsat_sentences:
            doc.write(str(sentence) + '\n')
        doc.write('\n\n\n================================== \n\n\n')
        doc.write('filtered_sentences_ = \n')
        for sentence in filtered_sentences_:
            doc.write(str(sentence) + '\n')
        doc.write('\n\n\n================================== \n\n\n')
        for sentence in sorted_sat_sentences:
            doc.write(str(sentence) + '\n')
        doc.write('\n\n\n================================== \n\n\n')


def write_csv_with_experim_info(exper_start_cpu_time, exper_start_time, ab_template_path, num_of_test_cases,
                                total_num_sentences, num_testcases_to_create_per_combination, filtered_sentences_,
                                num_unsat_sentences):
    exper_end_time = int(time.time())  # int() is to truncate decimals
    exper_end_cpu_time = float(time.process_time())
    total_cpu_time = str(exper_end_cpu_time - exper_start_cpu_time)
    total_exp_time = str(int(exper_end_time) - int(exper_start_time))
    print("Total experiment time =", total_exp_time + 's')
    datetime_exper_start_time = str(datetime.fromtimestamp(exper_start_time))
    datetime_exper_end_time = str(datetime.fromtimestamp(exper_end_time))
    num_filtered_sentences = len(filtered_sentences_)

    header = ['exper_start_time', 'template_name', 'experim_start_time', 'experim_end_time', 'total_exp_time',
              'total_cpu_time', 'num_test_cases_generated', 'total_num_sentences',
              'num_testcases_to_create_per_combination', 'num_filtered_sentences',
              'num_unsat_sentences']  # in case of normal .csv
    data = [exper_start_time, [ab_template_path][0], datetime_exper_start_time, datetime_exper_end_time,
            total_exp_time, total_cpu_time, str(num_of_test_cases), str(total_num_sentences),
            str(num_testcases_to_create_per_combination), str(num_filtered_sentences), str(num_unsat_sentences)]
    # [abstract_template_path] is to avoid csvwriter writing a comma after each character of the string
    with open(r'../../experiment_results/' + str(which_k_folder) + '/' + str(exper_start_time) + '/experiment_info.csv',
              'w', newline='') as f:
        writer = csv.writer(f)  # create the csv writer
        writer.writerow(header)  # write the header
        writer.writerow(data)  # write multiple rows


def write_csv_sentences(sentences, sentences_type,
                        exper_start_time):  # to write sat, unsat, with issues, and sorte_sat_sentences
    fieldnames = list(sentences[0].keys())
    for sentence in sentences:  # to strip the "\n" that make the csv a mess
        # print("sentence['constraint'] = ", sentence['constraint'])
        if isinstance(sentence['constraint'], list):
            for index in range(len(sentence['constraint'])):
                sentence['constraint'][index] = re.sub(r'\n', '', sentence['constraint'][index])
        else:
            sentence['constraint'] = re.sub(r'\n', '', sentence['constraint'])
    with open(r'../../experiment_results/' + str(which_k_folder) + '/' + str(
            exper_start_time) + '/' + sentences_type + '.csv', 'w',
              newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)  # in case of dict
        writer.writeheader()
        for row in sentences:
            writer.writerow(row)  # write multiple rows


def write_csv_cov_sent_per_tc(sentences_covered_per_tc, exper_start_time, filename):
    fieldnames = list(sentences_covered_per_tc[0].keys())
    with open(r'../../experiment_results/' + str(which_k_folder) + '/' + str(exper_start_time) + filename, 'w',
              newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames,
                                delimiter=',')  # different delimiter because of "," in the dict? maybe not needes
        writer.writeheader()
        for row in sentences_covered_per_tc:
            writer.writerow(row)  # write multiple rows


def write_csv_single_choices(new_list_single_choices, exper_start_time):
    # [abstract_template_path] is to avoid csvwriter writing a comma after each character of the string
    with open(r'../../experiment_results/' + str(which_k_folder) + '/' + str(
            exper_start_time) + '/single_choices_list.csv', 'w', newline='') as f:
        writer = csv.writer(f)  # create the csv writer
        # writer.writerow(header)  # write the header
        writer.writerow(new_list_single_choices)  # write multiple rows


def without_keys(d, keys):  # to return a dict without some specific keys
    return {x: d[x] for x in d if x not in keys}


########################################################################
#                                                                      #
########################################################################


""" ALGORITHM:
        0) Convert TAF template to the XML syntax for nodes.tag and Parse it
        1) Extract list of choices (and add more manually) (also called atomic sentences)
            from the original TAF XML template.
        2) Generate list of complex sentences from the list of choices. A sentence is in the form:
            choice(obj1) = xyz AND choice(obj2) = zyx AND link(obj1, obj2)==acceptable LCA path.
            LINK contains the Xpath to find all the Common Ancestors of the two nodes satisfying choice1 and choice2,
            not just the LCA. I could not find a general way to find just the LCA, unless it is the first ancestor.

            2.1) Create constraints and xpath expressions for each sentence.

        3) While the "sentences" list has sentences that are not satisfied ('satisfied'=False)
            4) Generate XML template "i" with constraint "i".  E.g. template_1 with constraint_from_sentence_1
            5) Call TAF to parse this template_i and generate "k" Test_Cases.
                5.1) Convert the syntax of the TC to XML syntax with proper nodes.tag
            6) Parse the "k" converted test_cases and check which sentences are covered.
                If TAF cannot generate a test_case, set this sentence to 'satisfied' = unsat. And put it in the unsat list
                6.1) select the test case that covers the most sentences.
                Set to 'satisfied' = True the values of all the sentences that are satisfied inside the selected
                test_case and put them in the covered/satisfied list
        7) When the sentences list is empty return the covered and unsat sentences"""


########################################################################
#
########################################################################


def main(num_test_cases_to_create_per_combination, abstract_template_path, timeout_taf, use_unguided_approach,
         taf_src_folder, which_k_folder):
    ########################################################################
    # Variables and set up the folders for the experiment
    ########################################################################
    exper_start_time = int(time.time())  # int() is to truncate decimals
    exper_start_cpu_time = float(time.process_time())
    os.chdir(
        taf_src_folder)  # change dir because TAF uses the paths inside settings.xml # absolute path, to avoid issues with multiple executions of main(), because, if it is in the if __main__, it had issues.
    exp_dir = '../experiment'
    create_dir('../../experiment_results/' + str(which_k_folder) + '/' + str(
        exper_start_time))  
    create_dir('../templates/pairwise/')
    num_of_partitions = 3  # num of partitions to divide the ranges of min-max.
    templates_path_for_experiment = "../templates/pairwise/"
    limit_num_tcs_for_unguided = 100

    clean_previous_exp_files_and_folders(exp_dir)

    # the next prints() are just to have the names in the log file. It is normal that they are the same as above
    print("abstract_template_path =", str(abstract_template_path))
    print("num_test_cases_to_create_per_combination =", str(num_test_cases_to_create_per_combination))
    print("timeout_taf =", str(timeout_taf))

    ########################################################################
    """ 0) Convert TAF abstract XML template to the XML syntax for nodes.tag and Parse it"""
    ########################################################################
    original_abstract_tree = etree.parse(
        abstract_template_path)  # remember to not include params directly in the "root" node,
    # but just inside the other nodes, like "row"
    # NOTE: parse() returns an ElementTree object, not an Element object as the string parser functions:
    # og_abstract_root = original_abstract_tree.getroot()

    template_elems_path_and_nb_instances, root_name, converted_abstract_root, converted_abstract_tree = create_list_elem_with_path(
        abstract_template_path)

    ########################################################################
    """ 1) Extract list of choices/choices (and add more manually) (also called atomic sentences)
        from the original/abstract TAF XML template.
        Constraints could already be prepared, but just for single values or choices.
        """
    ########################################################################
    # The extraction from the elements inside converted_abstract_root
    new_list_single_choices = create_list_of_choices(template_elems_path_and_nb_instances, root_name, num_of_partitions)

    # manually added choices:
    # Write some additional choices in xpath syntax, that would use the constraints with forall, OR, IMPLIES of TAF
    # NOTE the constraints linked to the manually added xpath have to be implemented!!
    manually_added_xpath_choices = []  # in the form of {'': '' .....}
    for added_choice in manually_added_xpath_choices:
        new_list_single_choices.append(added_choice)

    ########################################################################
    """ 2) Generate list of complex sentences/pairs from the list of choices. A sentence is in the form:
            EXIST obj1, obj2 SUCH AS  choice(obj1) = xyz AND choice(obj2) = zyx AND  link(obj1, obj2)
            Each sentence contains: {prop1: 'nodes satisfying it', prop2: 'nodes satisfying it', 'link': '',
            'satisfied': False/True/unsat, 'test_cases': '', 'constraint': ''}
            2.1) Decide the link. Create constraints for each sentence. Constraints are generated based on the link/LCA.
            The link has to be decided in advance or here. """
    ########################################################################

    sentences, filtered_out_sentences = create_sentences_from_list_of_choices(new_list_single_choices)
    sentences = generate_taf_constraints_and_xpath_for_link(sentences, root_name, use_unguided_approach)
    print("len sentences after first filtering = ", len(sentences))
    print("len filtered out sentences after one pass  = ", len(filtered_out_sentences))
    # this function filters the pairs that cannot be sat, due to the constraints already present in the TAF template.
    # They have been computed manually from the constraints.
    sentences, filtered_sentences_second_pass = filter_impossible_sentences_tax_payer_from_taf_constraints(sentences,
                                                                                                           abstract_template_path)
    print("len sentences AFTER SECOND filtering = ", len(sentences))

    for elem in filtered_sentences_second_pass:
        filtered_out_sentences.append(elem)

    print("len filtered out sentences after two passes  = ", len(filtered_out_sentences))
    len_sentences_pairs = len(sentences)

    """ Manually add sentences of choice, or taken from the constraints of the template and transfrom them with DNF
    (disjunctive normal form, like A or B or C) and verify every property """
    # manually add sentences. Not choices, complete sentences, the TAF constraints and XPATH expressions have to be written manually!
    manually_added_xpath_sentences = add_manual_sentences()  # these sentences have been obtained by using
    # DNF Disjunctive normal form from the constraints already present in the templates.

    for added_sentence in manually_added_xpath_sentences:
        sentences.append(added_sentence)
    for idx, sentence in enumerate(sentences):
        if idx > len_sentences_pairs - 1:
            sentence['index'] = idx  # add indexes to the manually added sentences.
    total_num_sentences = len(sentences)

    ########################################################################
    """ 3) While "sentences" has keys with values: {.., 'satisfied' = False, ..} , do ... """
    ########################################################################
    #  while the list is not empty, put the satisfied sentences in a list, then the unsat in another list

    index_i = 0  # index of the pairwise_i.template
    print("Overwriting TAF settings for 'nb_test_cases' = ", num_test_cases_to_create_per_combination)
    taf_overwrite_setting("nb_test_cases", num_test_cases_to_create_per_combination)
    taf_overwrite_setting("nb_test_artifacts", str(1))

    unsat_sentences = []  # contains all the sentences with {'satisfied'='unsat'}
    sat_sentences = []  # contains all the sentences with {'satisfied'='True'}
    # sentences should be empty at the end, and all the original items of sentences should be
    # inside unsat_sentences or sat_sentences

    num_of_test_cases = 0
    sentences_covered_per_tc = []
    while sentences and index_i < limit_num_tcs_for_unguided:  # termination condition is sentences empty, or after 100 tc_generated,
        # or 100 ierations, or timer/watchdog has reached the threshold. Used to stop the unguided
        print("Working on next sentence, iteration =", index_i)
        # create copy of template, whose constraints will be modified soon to add the restriction on the pair values
        target_template_path = r'../templates/pairwise/template{index}.xml'.format(
            index=index_i)  # the folder has to exist already, or it has to be created
        shutil.copyfile(abstract_template_path, target_template_path)  # create a copy of the template, to which the
        # constraint will be added
        print("Overwriting TAF settings for 'template_path' =", templates_path_for_experiment)
        taf_overwrite_setting("template_path", templates_path_for_experiment)
        # Using taf_overwrite_setting. TAF will say: XXX: mode auto  |unknown syntax: ../templates/pairwise/.
        # This does not cause issues, but the message will be fixed.
        print("Overwriting TAF settings for 'template_file_name' =", "template{index}.xml".format(index=index_i))
        taf_overwrite_setting("template_file_name", "template{index}.xml".format(index=index_i))

        ########################################################################
        """ 4) Generate XML template "i" with constraint "i"  e.g. template.1 with constraint.12"""
        ########################################################################
        add_to_root_bool = sentences[0][
                               'xpath_elem_where_to_add_constr'] == ''  # change and make it more robust, what if I put here /root instead of ''?
        write_template_with_new_constraint(sentences[0], original_abstract_tree, add_to_root_bool, target_template_path,
                                           use_unguided_approach)
        ########################################################################
        """ 5) Call TAF to parse this template_i and generate the Test_Case_"i". Or "k" new test cases. """
        ########################################################################

        print("Asking TAF to generate sentence =", sentences[0])
        taf_could_generate = exec_taf(
            timeout_taf)

        if not taf_could_generate:  # if TAF cannot generate a TC, set sentence[0]['satisfied'] = 'unsat'
            remove_unsat_sentence(sentences, index_i, unsat_sentences, exper_start_time, target_template_path)
            index_i += 1
        else:
            ########################################################################
            """ 5.1) Convert the syntax of the TC to XML syntax with proper nodes.tag

            6) Parse the "k" converted test_cases and check which sentences are covered.
                If TAF cannot generate a test_case, set this sentence to 'satisfied' = unsat. And put it in the unsat list
            6.1) select the test case that covers the most sentences.
                Set to 'satisfied' = True the values of all the sentences that are satisfied inside the selected
                test_case and put them in the covered/satisfied list"""
            ########################################################################
            # # 5. Else select tc_i the test case that covers the most pairs in UC.  # done in execute_taf???? NOT True?
            # NOTE: "k" is a function of the template size/complexity and the number of constraints
            id_max_sat_sentences, indexes_of_sat_sentences_in_k_tcs = check_sat_sentences_in_k_testcases(sentences,
                                                                                                         index_i,
                                                                                                         num_test_cases_to_create_per_combination)
            print("len(sentences) BEFORE removing sat sentences =", len(sentences))
            if indexes_of_sat_sentences_in_k_tcs != [[] for ind_i in
                                                     range(num_test_cases_to_create_per_combination)]:  # to debug
                if indexes_of_sat_sentences_in_k_tcs[id_max_sat_sentences][0] != 0:
                    print(
                        f"{bcolors.WARNING}\n IGNORE if it is the experiment with unguided and without pairwise. "
                        f"WARNING. There was a mismatch, XPATH could not find the pair  associated with the TAF "
                        f"constraint.\n{bcolors.ENDC}")

            num_sat_sentences_for_this_tc = len(indexes_of_sat_sentences_in_k_tcs[id_max_sat_sentences])
            sat_sentences_for_this_tc = []
            for index in indexes_of_sat_sentences_in_k_tcs[id_max_sat_sentences]:
                sat_sentences_for_this_tc.append(sentences[index])

            if use_unguided_approach and num_sat_sentences_for_this_tc == 0:  # it means that the test case generated at
                # unguided is not covering a new sentence, so we can discard it.
                clean_previous_exp_files_and_folders(exp_dir)  # remove the template and the generated test case
            else:
                sentences_covered_per_tc.append({'tc_num': str(num_of_test_cases),
                                                 'num_sat_sentences_of_this_tc': num_sat_sentences_for_this_tc,
                                                 'list_of_sat_sentences_of_this_tc': sat_sentences_for_this_tc})
                sentences = remove_sentences_of_indexes(sentences,
                                                        indexes_of_sat_sentences_in_k_tcs[id_max_sat_sentences],
                                                        sat_sentences)

                print("len(sentences) AFTER removing sat sentences =", len(sentences))
                # move result artifacts from TAF, otherwise TAF will try to update the existing files, this means problems
                mv_tc_to_backup_folder(index_i, exper_start_time, id_max_sat_sentences, exp_dir, target_template_path,
                                       which_k_folder)
                num_of_test_cases += 1  # does not count unsat iterations, unlike index_i
            index_i += 1

        print("\n\n"
              " ###########################################################\n",
              "##                                                       ##\n",
              "###########################################################\n")

    ###########################################################
    """ 7) return the covered and unsat sentences/pairs"""
    ###########################################################

    print("Iterations/templates needed to finish the experiment = ", index_i)
    print("Test cases generated = ", num_of_test_cases)
    print("number of sat_sentences =", len(sat_sentences))
    print("\n ==================================================")
    if sentences and use_unguided_approach:  # for the unguided algo, in case it could not empty the sentences list
        print("len sentences left and not sat by the unguided algorithm ", len(sentences))
        for sentence in sentences:
            unsat_sentences.append(sentence)

    if unsat_sentences:
        num_unsat_sentences = len(unsat_sentences)
        print("number of unsat_sentences =", len(unsat_sentences))
    else:
        num_unsat_sentences = 0
    print("\n unsat_sentences =")
    for elem in unsat_sentences:
        print(elem)

    sorted_sat_sentences = sorted(sat_sentences, key=itemgetter('index'))
    write_experiment_info_to_file(exper_start_cpu_time, exper_start_time, abstract_template_path, sat_sentences,
                                  unsat_sentences, filtered_out_sentences, sorted_sat_sentences, num_of_test_cases,
                                  total_num_sentences, num_test_cases_to_create_per_combination, num_unsat_sentences)
    write_csv_with_experim_info(exper_start_cpu_time, exper_start_time, abstract_template_path, num_of_test_cases,
                                total_num_sentences, num_test_cases_to_create_per_combination, filtered_out_sentences,
                                num_unsat_sentences)
    if sat_sentences:
        write_csv_sentences(sat_sentences, "sat_sentences", exper_start_time)
    if unsat_sentences:
        write_csv_sentences(unsat_sentences, "unsat_sentences", exper_start_time)
    if filtered_out_sentences:
        write_csv_sentences(filtered_out_sentences, "filtered_sentences", exper_start_time)
    write_csv_cov_sent_per_tc(sentences_covered_per_tc, exper_start_time, '/sentences_covered_per_tc.csv')
    write_csv_single_choices(new_list_single_choices, exper_start_time)

    keys_to_exclude = {'list_of_sat_sentences_of_this_tc'}
    sent_cov_per_tc_only_num = []
    for dict_ in sentences_covered_per_tc:
        sent_cov_per_tc_only_num.append(without_keys(dict_, keys_to_exclude))
    write_csv_cov_sent_per_tc(sent_cov_per_tc_only_num, exper_start_time, '/sentences_covered_per_tc_only_num.csv')

    # dir_to_remove = '../../experiment_results/' + str(exper_start_time)  # to remove the folder which name is the unix timestamp
    # os.rmdir(dir_to_remove)  # this directory should always be empty at the end!
    print("\n\n\n Experiment finished!")


if __name__ == '__main__':
    # This script does the experiments for one case study at each execution. So it is possible to execute multiple
    # experiments in parallel, with different folders and scripts. E.g. one for oz unguided, one for oz guided,
    # one taxpayer unguided, and one taxpayer guided.
    # Do not change the folders paths or names.

    print("Remember to change here in the script the path to your TAF folder! \n"
          "Then select in the script which case study you want to use (Oz or Taxpayer).\n"
          "Select also the type of experiment (Unguided with just TAF, or guided with TAF with the pairwise guidance.\n"
          "Lastly, select the number of runs/repetitions. \n"
          "The script is made to be used in parallel with copies of the same script, in order to run multiple case studies in parallel.\n"
          "It is important that the folders structure is respected, so do not change the folders in the replication "
          "package, and change just the four parameters mentioned above.\n"
          "You can also run the bash script with, for example:"
          " 'bash run_oz_k.sh 2>&1 | tee -a  experiment.log' "
          "to save an experiment.log file.\n"
          "It is important to use the TAF version provided in the replication package, as there is a modification "
          "compared to the official TAF git.\n"
          "It is possible to perform the statistical analysis with the other script.\n")

    num_of_runs = 50
    unguided_no_choices = True  # select True if you want the unguided unguided approach (just TAF),
    # or False for the guided approach (TAF+ pairwise)
    # do not use taf_src_folder = './taf/src/', as the full path is needed inside the main()

    taf_src_folder = '/home/......./2022.10.99/oz_random/taf/src/'  # IMPORTANT everything is a relative path compared to this!

    which_case_study = 'oz'  # uncomment here to change the case study to oz, so it can be used in another sript in parallel
    # which_case_study = 'tax_payer'

    #########################################################################################
    #  Do not change anything else below this line
    #########################################################################################
    if which_case_study == 'oz':
        abstract_template_path = '../templates/ozExample/oz_upd.template'  # do not change name or path
        timeout_taf = 120  # empirically chosen depending on the PC
    elif which_case_study == 'tax_payer':
        timeout_taf = 200  # empirically chosen depending on the PC
        abstract_template_path = '../templates/taxPayerExample/tax_payer_upd.template'  # do not change name or path
    else:
        print(f"{bcolors.WARNING}\n CHECK in which folder the template is, because sometimes there are "
              f"inconsistencies with the names \n{bcolors.ENDC}")
        quit()

    str_path = str(abstract_template_path)
    list_tc_per_exp = [1, 3, 5, 7]  # the K parameter

    for num_test_cases_to_create_per_combination in list_tc_per_exp:
        which_k_folder = 'k_' + str(num_test_cases_to_create_per_combination)
        for i in range(num_of_runs):
            main(num_test_cases_to_create_per_combination, abstract_template_path, timeout_taf, unguided_no_choices,
                 taf_src_folder, which_k_folder)
            print("\n runs" + str(i) + " of " + which_case_study + " with k = " + str(
                num_test_cases_to_create_per_combination) + " finished \n ////////////////////////////////////////////")
        print("\n " + str(num_of_runs) + " runs of " + which_case_study + "with k =" + str(
            num_test_cases_to_create_per_combination) + " finished \n ||||||||||||||||||||||||||||||||||||||||||||||||")
