#!/bin/bash

################################################################################
# DESCRIPTION:
# This script works in tandem with the "TAF test case generation tool" by C. Robert
# it launches the pairwise/combinatorial framework to carry out the experiment for the paper

################################################################################
#NB: when you use variables in the code, use ${} to avoid problems with trailing special characters, e.g., ${VAR}_ =/= $VAR_
# bash execute_framework_script.sh 2>&1 | tee -a  experiment.log
# 2>&1 redirects channel 2 (stderr/standard error) into channel 1 (stdout/standard output), such that both is written as stdout.

################################################################################
# 2.
# PARAMETERS
################################################################################
START=$(date +%s) # used to determine the total execution time of the experiment/script # in Unix time
EXPERIMENT_START_TIME=$(date +'%Y-%m-%d_%H.%M.%S')
EXPERIMENT_NAME=exp_pairwise_tax_payer_k_1357_random
PY_SCRIPT_TO_EXEC=tax_payer_random.py

################################################################################
# 3.
#
################################################################################
# KILL open processes
# killall -9 python3  # echo "Killing previously open processes, if any."
echo ""
echo "Every line that starts with '--' is from the bash script, the rest is from the python framework"
echo "-------------------------------------------------------------------------"
echo ""
echo "--Your experiment is called $EXPERIMENT_NAME.--"
echo ""
echo "--The experiment start time is  $EXPERIMENT_START_TIME"
echo "--To debug, launch this script with: bash -x ./script_name.sh | tee -a logfile , or output it to a file directly--"
echo "--Do NOT suspend the experiment using ctrl+z in the terminal because the test will FAIL.
But if you do, then type  jobs  to see the job number and  fg  or  fg num_of_job  to restart--"
echo "--Enjoy the ride! LVS--"
echo ""
echo "-------------------------------------------------------------------------"
sleep 0.1

################################################################################
# 3.1 START of the SCRIPT
# PAIRWISE combinations GENERATION with TAF
################################################################################

EXPERIMENT_START_TIME_i=$(date +'%Y-%m-%d_%H.%M.%S')
echo ""
echo "--experiment_run_num_$i."
echo "--EXPERIMENT_i_START_TIME=$EXPERIMENT_START_TIME_i"
echo ""
python3 $PY_SCRIPT_TO_EXEC

EXPERIMENT_ENDTIME=$(date +'%Y-%m-%d_%H.%M.%S')

END=$(date +%s)
DIFF=$(echo "$END - $START" | bc)
echo "--Experiment EXPERIMENT_NAME concluded. Endtime = $EXPERIMENT_ENDTIME --"
echo "--Completed in $DIFF seconds--"

echo "--=================================================="
