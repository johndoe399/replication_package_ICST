def export(root_node, path):
	pass