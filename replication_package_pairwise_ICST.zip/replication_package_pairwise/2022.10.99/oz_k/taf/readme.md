--- TAF: Testing Automation Framework ---
===============================

The purpose of TAF is to generate random test cases from a template file describing the data model. TAF provides a command line interface. When launched, type "help" in the prompt to get a list of the available commands.
Type "help <command_name>" to get specific info on a command.


Requirements:
-----------
 * Python 3.6
Packages:
 * Numpy 1.18.4
 * z3-solver 4.8.8.0

Installation:
-----------
 follow the video or use the transcript after installing python 3.6


 Typical usage:
-----------
 (more details in the [video]([TAF_tutorial_x265.mp4 at master))


```
cd path/TAF/src
python3 Taf.py         %launch TAF
display all            %visualize the settings
parse_template         %parse the template
generate               %generate test cases
cat ../experiment/test_case_0/test_case_0.test_case %visualize the result
```
Please remove the generated "experiments" folder to launch again new generation with "generate" or change the name of the folder.

To change the default example (bitmap) to another one:
- copy/paste the .template file from "templates/xxxExample/", into the "templates" folder
- copy/paste the .export file from "templates/xxxExample/" into the "src" folder
- restart TAF


Contents of the repository:
-----------

 1. src: the source code and the default settings
 2. templates : Examples of templates and export files, including:
 	* a bitmap generator (bmp.template)
 	* an environnement for an agricultural robot (oz.template)
 	* a data-base for tax payer (tax_payer.template)
  * a tree (connected acyclic graph) generator (tree.template)
 	* and many more
 3. docs: demonstration video + XML-TAF language specification
 4. paper_results: a specific folder containing experiments and results for the evaluation of diversity and performance of Taf



This software is released under CeCILL-B license (similar to BSD, without copyleft)
with Copyright 2019.
 ______

		                 ______			
	        	         /     /\
		               /     /##\
		              /     /####\
	        	      /     /######\
		            /     /########\
		           /     /##########\
	        	   /     /#####/\#####\
		         /     /#####/++\#####\
		        /     /#####/++++\#####\
		       /     /#####/\+++++\#####\
		      /     /#####/  \+++++\#####\
		     /     /#####/    \+++++\#####\
		    /     /#####/      \+++++\#####\		
		   /     /#####/        \+++++\#####\
		  /     /#####/__________\+++++\#####\
		 /                        \+++++\#####\
		/__________________________\+++++\####/
		\+++++++++++++++++++++++++++++++++\##/
		 \+++++++++++++++++++++++++++++++++\/
		  ``````````````````````````````````
