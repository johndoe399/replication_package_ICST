import csv
import os
import matplotlib.pyplot as plt
import numpy as np
from numpy import array, average
import pandas as pd
from pingouin import mwu
from matplotlib.ticker import MaxNLocator  # to have axis with just integers # DOESN'T work

def read_csv_with_dict(filename):
    with open(filename, "r") as f:
        csv_dict_reader = csv.DictReader(f, delimiter=',')
        data = []
        for item in csv_dict_reader:
            data.append(dict(item))  # dict() to transform from orderedDict
    return data


def read_csv(filename):
    with open(filename, "r") as file:
        csv_reader = csv.reader(file, delimiter=',')
        headers = next(csv_reader)
        data = {}
        for title in headers:
            data[title] = []

        for row in csv_reader:
            for i, title in enumerate(headers):
                data[title].append(row[i])
    return data


def plot_figure_(data):
    # figure
    fig, ax = plt.subplots()
    ax.plot(data["tc_num"], data["num_sat_sentences_of_this_tc"])
    plt.xlabel("Test case number")
    plt.ylabel("Covered pairs")
    ax.yaxis.set_major_locator(MaxNLocator(integer=True))
    fig.show()


def plot_figures(data_list, x_key, y_key, title, x_label, y_label):
    fig = plt.figure(dpi=600)
    ax1 = fig.add_subplot(111)
    for data in data_list:
        ax1.plot(data[x_key], data[y_key])
        plt.title(title)
        plt.xlabel(x_label)
        plt.ylabel(y_label)
    ax1.yaxis.set_major_locator(MaxNLocator(integer=True))
    plt.show()
    fig.savefig('_fig.png', dpi=600)
    fig.savefig('_fig.pdf')


def plot_cdf(data_list, title, label1, label2, xmax=None, ymin=None,
             data2compare=None):  # cumulative distribution function, not normalized
    save_name = label1 + "_" + label2
    fig = plt.figure(dpi=600)
    ax = fig.add_subplot(111)
    for i, data in enumerate(data_list):
        cdf = np.cumsum(data["num_sat_sentences_of_this_tc"])
        plt.plot(data["tc_num"], cdf, color="blue")  # , label="CDF" + str(i))
        if data2compare:
            cdf2 = np.cumsum(data2compare[i]["num_sat_sentences_of_this_tc"])
            plt.plot(data2compare[i]["tc_num"], cdf2, color="red")  # , label="exp2_CDF" + str(i))
    plt.legend([label1, label2])
    plt.title(title)
    fig.show()
    fig.savefig(save_name + '_cdf.png', dpi=600)
    fig.savefig(save_name + '_cdf.pdf')


def isfloat(num):
    try:
        float(num)
        return True
    except ValueError:
        return False


def convert_data_to_int(data):
    dict_keys = list(data.keys())
    for i, key in enumerate(dict_keys):
        for j in range(len(data[dict_keys[i]])):
            if isfloat(data[dict_keys[i]][j]):
                if '.' in data[dict_keys[i]][j]:
                    # it is a float, like total_cpu_time
                    data[dict_keys[i]][j] = float(data[dict_keys[i]][j])
                else:  # it is an int
                    data[dict_keys[i]][j] = int(data[dict_keys[i]][j])
    return data


def check_if_elem_is_uniques(data_list):
    # concatenate list of lists of dicts
    new_list_with_repeated_elems = []
    for list_ in data_list:
        for dict_ in list_:
            new_list_with_repeated_elems.append(dict_)
    elems_count = count_elements(new_list_with_repeated_elems)
    uniques_elem_indexes = get_uniques_indexes(elems_count)
    return uniques_elem_indexes


def count_elements(list_with_duplicates):
    elems_count = {}
    for elem in list_with_duplicates:
        if elem['index'] in elems_count:
            elems_count[str(elem['index'])] += 1
        else:
            elems_count[str(elem['index'])] = 1

    return elems_count


def get_uniques_indexes(elems_counts):
    uniques_indexes = []  # list containing the indexes of the unique elements
    dict_keys = list(elems_counts.keys())
    for key in dict_keys:
        if elems_counts[key] == 1:
            uniques_indexes.append(key)
    return uniques_indexes



def create_data_from_experiment(csv_path, csv_to_read, is_dict):
    data_list = []
    for exp_dir in os.listdir(csv_path):  # inside /11112923382/
        path_to_file = csv_path + exp_dir + csv_to_read
        if os.path.exists(path_to_file):
            if is_dict:
                data = read_csv_with_dict(path_to_file)
                data_list.append(data)
            else:
                data = read_csv(path_to_file)
                data_list.append(convert_data_to_int(data))
    return data_list


def find_mean(
        list_of_numbers):
    sum_n = sum(list_of_numbers)
    len_n = len(list_of_numbers)
    mean = sum_n / len_n
    return mean


def find_median(
        list_of_numbers):
    list_of_numbers.sort()
    length = len(list_of_numbers)
    length_is_odd = True if length % 2 == 0 else False
    if length_is_odd:
        index = length // 2
        median = list_of_numbers[index]
    else:
        index_1 = length // 2
        index_2 = index_1 + 1
        median = (list_of_numbers[index_1] + list_of_numbers[index_2]) / 2
    return median


def find_range(list_of_numbers):
    n_min = min(list_of_numbers)
    n_max = max(list_of_numbers)
    n_range = n_max - n_min
    return n_min, n_max, n_range


def get_exps_times_and_sat_sentences(list_of_dicts):
    exp_times = []
    exp_cpu_times = []
    num_unsat_sentences = []
    num_sat_sentences = []
    num_tc_generated = []
    for dict_ in list_of_dicts:
        exp_times.append(dict_['total_exp_time'][0])
        exp_cpu_times.append(dict_['total_cpu_time'][0])
        if dict_['num_unsat_sentences'] == []:
            num_unsat_sentences.append(0)
        else:
            num_unsat_sentences.append(dict_['num_unsat_sentences'][0])
        num_sat_sentences.append(dict_['total_num_sentences'][0] - num_unsat_sentences[-1])
        num_tc_generated.append(dict_['num_test_cases_generated'][0])

    return exp_times, exp_cpu_times, num_unsat_sentences, num_sat_sentences, num_tc_generated


def get_mean_min_max_between_two_exps(two_experiments):
    mean_times = []
    mean_cpu_times = []
    mean_unsat_sent = []
    mean_sat_sent = []
    median_times = []
    median_cpu_times = []
    median_unsat_sent = []
    median_sat_sent = []
    max_times = []
    min_times = []
    max_cpu_times = []
    min_cpu_times = []
    max_unsat_sent = []
    min_unsat_sent = []
    max_sat_sent = []
    min_sat_sent = []
    num_tc_generated = []
    max_tc_generated = []
    min_tc_generates = []
    mean_num_tc = []
    max_min_delta_tc = []
    max_min_delta_unsat = []

    for experiment_data in two_experiments:
        exp_times, exp_cpu_times, num_unsat_sent, num_sat_sent, num_tc_generated_per_exp = get_exps_times_and_sat_sentences(
            experiment_data)
        mean_times.append(find_mean(exp_times))
        mean_cpu_times.append(find_mean(exp_cpu_times))
        mean_unsat_sent.append(find_mean(num_unsat_sent))
        mean_sat_sent.append(find_mean(num_sat_sent))
        median_times.append(find_median(exp_times))
        median_cpu_times.append(find_median(exp_cpu_times))
        median_unsat_sent.append(find_median(num_unsat_sent))
        median_sat_sent.append(find_median(num_sat_sent))
        max_times.append(max(exp_times))
        min_times.append(min(exp_times))
        max_cpu_times.append(max(exp_cpu_times))
        min_cpu_times.append(min(exp_cpu_times))
        max_unsat_sent.append(max(num_unsat_sent))
        min_unsat_sent.append(min(num_unsat_sent))
        max_sat_sent.append(max(num_sat_sent))
        min_sat_sent.append(min(num_sat_sent))
        num_tc_generated.append(num_tc_generated_per_exp)
        mean_num_tc.append(find_mean(num_tc_generated_per_exp))
        max_min_delta_tc.append(max(num_tc_generated_per_exp) - min(num_tc_generated_per_exp))
        max_min_delta_unsat.append(max(num_unsat_sent) - min(num_unsat_sent))
        max_tc_generated.append(max(num_tc_generated_per_exp))
        min_tc_generates.append(min(num_tc_generated_per_exp))

    print("mean_times =", mean_times)
    print("median_times", median_times)
    print("max_times", max_times)
    print("min_times", min_times)

    print("mean_cpu_times", mean_cpu_times)
    print("median_cpu_times", median_cpu_times)
    print("max_cpu_times", max_cpu_times)
    print("min_cpu_times", min_cpu_times)

    print("mean_unsat_sent", mean_unsat_sent)
    print("median_unsat_sent", median_unsat_sent)
    print("max_unsat_sent", max_unsat_sent)
    print("min_unsat_sent", min_unsat_sent)

    print("mean_sat_sent", mean_sat_sent)
    print("median_sat_sent", median_sat_sent)
    print("max_sat_sent", max_sat_sent)
    print("min_sat_sent", min_sat_sent)

    print("mean_num_tc_ =", mean_num_tc)
    print("max_min_delta_tc = ", max_min_delta_tc)
    print("max_min_delta_unsat = ", max_min_delta_unsat)
    print("max_tc_generated =", max_tc_generated)
    print("min_tc_generates =", min_tc_generates)

    return num_tc_generated


def get_mann_whitney_u_test(list1, list2, name_1, name_2, title):
    # give the num of tc to cover the tc for
    print("mann whitney u test results for ")
    print(name_1 + " and " + name_2)
    data = {name_1: list1,
            name_2: list2}
    df = pd.DataFrame(data)  # , columns=['num_tc_method_1', 'num_tc_method_2'])  # Dictionary to Dataframe
    # useful for see a lot of info at once, specific info can be accessed with [index]
    # print(df.describe())  # or display(df.describe()) from ipython
    results2 = mwu(df[name_1], df[name_2], tail='one-sided')
    print(results2)
    names = [name_1, name_2]
    label = 'Number of test cases generated'
    # print_boxplot_dataframe(df, names, title, label)


def box_plot_list_of_experiments(data_list, names, title, label):
    data = {}
    for i, exper in enumerate(data_list):
        data[names[i]] = exper
    df = pd.DataFrame(data)  # dict to dataframe
    print_boxplot_dataframe(df, names, title, label)


def print_boxplot_dataframe(df, names, title, label):
    fig = plt.figure(dpi=600)
    axarr = df.boxplot(column=names, grid=False, color=dict( medians='r'), medianprops=dict(linestyle='-', linewidth=2.5), ax=plt.gca())
    axarr.set_title(title)
    axarr.set_ylabel(label)
    axarr.plot()
    fig.set_size_inches(8, 6)
    plt.show()
    fig.savefig(title + '_boxplot.png', dpi=600)
    fig.savefig(title + '_boxplot.pdf')  # , dpi does not apply to .pdf


def find_unique_unsat_sentences(csv_path, title, csv_unsat_sent_dict_to_read):
    # read_unsat_sentences
    unsat_sentences_for_each_tc = create_data_from_experiment(csv_path, csv_unsat_sent_dict_to_read, True)
    indexes_unique_elems = check_if_elem_is_uniques(unsat_sentences_for_each_tc)
    full_unsat_sent_from_all_tc = []
    unsat_sentences_from_all_tc = []
    for list_for_each_run in unsat_sentences_for_each_tc:
        for elems_list in list_for_each_run:
            if elems_list['constraint'] not in unsat_sentences_from_all_tc:
                unsat_sentences_from_all_tc.append(elems_list['constraint'])
            if elems_list not in full_unsat_sent_from_all_tc:
                full_unsat_sent_from_all_tc.append(elems_list)

    print("unsat_sentences_from_all_tc =")
    for elem in unsat_sentences_from_all_tc:
        print(elem)

    print("len unsat_sentences_from_all_tc =", len(unsat_sentences_from_all_tc))

    print("title =", title)
    for index in indexes_unique_elems:
        for list_sentences in unsat_sentences_for_each_tc:
            for sentence in list_sentences:
                if sentence['index'] == index:
                    print(sentence)


def plot_cdf_comparison(data_list, title, label1, label2, xmax=None, ymin=None,
                        data2compare=None):  # cumulative distribution function, not normalized
    save_name = label1 + "_" + label2
    fig = plt.figure(dpi=600)
    ax = fig.add_subplot(111)
    for i, data in enumerate(data_list):
        cdf = np.cumsum(data["num_sat_sentences_of_this_tc"])
        plt.plot(data["tc_num"], cdf, color="blue")  # , label="CDF" + str(i))
        if data2compare:
            cdf2 = np.cumsum(data2compare[i]["num_sat_sentences_of_this_tc"])
            plt.plot(data2compare[i]["tc_num"], cdf2, color="red")  # , label="exp2_CDF" + str(i))
    plt.legend([label1, label2])
    plt.title(title)
    ax.yaxis.set_major_locator(MaxNLocator(integer=True))
    fig.show()
    fig.savefig(save_name + 'comparison_cdf.png', dpi=600)
    fig.savefig(save_name + 'comparison_cdf_cdf.pdf')


def tsplot(x, y, n=20, percentile_min=1, percentile_max=99, color='r', plot_mean=False, plot_median=True,
           line_color='k', **kwargs):
    # calculate the lower and upper percentile groups, skipping 50 percentile
    perc1 = np.percentile(y, np.linspace(percentile_min, 50, num=n, endpoint=False), axis=0)
    perc2 = np.percentile(y, np.linspace(50, percentile_max, num=n + 1)[1:], axis=0)

    if 'alpha' in kwargs:
        alpha = kwargs.pop('alpha')
    else:
        alpha = 1 / n
    # fill lower and upper percentile groups
    for p1, p2 in zip(perc1, perc2):
        plt.fill_between(x, p1, p2, alpha=alpha, color=color, edgecolor=None)
    if plot_mean:
        plt.plot(x, np.mean(y, axis=0), color=line_color)
    if plot_median:
        plt.plot(x, np.median(y, axis=0), color=line_color)
    return plt.gca()


def find_max_list(list):
    list_len = [len(i) for i in list]
    return max(list_len)


def extend_cdfs(cdfs):  # use np.pad because they are np array
    max_for_each_cdf = []
    for elem in cdfs:
        max_for_each_cdf.append(find_max_list(elem))
    max_len = max(max_for_each_cdf)
    extended_cdfs = []
    for cdf in cdfs:
        extended_single_cdf = []
        for elem in cdf:
            elems_added_to_length = max_len - len(elem)
            padded_elem = np.pad(elem, (0, elems_added_to_length), 'edge')
            extended_single_cdf.append(padded_elem)
        extended_cdfs.append(extended_single_cdf)
    return extended_cdfs


def compute_cdfs(experiments_data):
    cdfs = []
    for elem in experiments_data:
        cdfs.append(compute_cdf(elem))
    return cdfs


def compute_cdf(data_list):
    cdfs = []
    for i, data in enumerate(data_list):
        cdfs.append(np.cumsum(data["num_sat_sentences_of_this_tc"]))
    return cdfs


def create_lists_for_comparison(extended_cdfs):
    lis_of_lists_of_sat_sentences_for_comparison = []
    for cdf in extended_cdfs:
        lis_of_lists_of_sat_sentences_per_tc = []
        for elem in cdf:
            lis_of_lists_of_sat_sentences_per_tc.append(elem)
        lis_of_lists_of_sat_sentences_for_comparison.append(lis_of_lists_of_sat_sentences_per_tc)
        array_lol = array(lis_of_lists_of_sat_sentences_per_tc)
        column_average = average(array_lol, axis=0)
    return lis_of_lists_of_sat_sentences_for_comparison


def plot_with_quantiles(lis_of_lists_of_sat_sentences_for_comparison, title, labels, xlabel, ylabel, xmin=None,
                        xmax=None, ymin=None):
    fig = plt.figure(dpi=600)
    ax = fig.add_subplot(111)

    for idx, list_sat_sent_of_one_exp in enumerate(lis_of_lists_of_sat_sentences_for_comparison):
        colors = ['g', 'b', 'r', 'y']
        line_color = ['green', 'navy', 'red', 'yellow']
        # IQR
        x = [i for i in range(1, len(list_sat_sent_of_one_exp[0]) + 1)]
        ax1 = tsplot(x, list_sat_sent_of_one_exp, n=1, percentile_min=25, percentile_max=75, plot_median=True,
                     plot_mean=False, color=colors[idx],
                     line_color=line_color[idx], alpha=0.3)
        #  90% interval
        # ax2 = tsplot(x, list_sat_sent_of_one_exp, n=1, percentile_min=5, percentile_max=95, plot_median=True,
        #              plot_mean=False,
        #        color=colors[idx],
        #        line_color=line_color[idx], alpha=0.3)
    ax.set_xlim(xmax=xmax)
    ax.set_xlim(xmin=xmin)
    plt.legend(labels, loc='lower right')
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.xticks(range(1, len(list_sat_sent_of_one_exp[0]) + 1, 2))  # to have the x-axis with integers
    # remove plt.xticks() if you want to use ax.set_xlim
    fig.show()
    fig.savefig(title + '_cdf.png', dpi=600)
    fig.savefig(title + '_cdf.pdf')


def pdf_cdf(data_list):
    list_tc_per_run = []
    for i, data in enumerate(data_list):
        list_tc_per_run.append(np.cumsum(data["num_sat_sentences_of_this_tc"]))
    # finding the PDF of the histogram using count values
    fig = plt.figure(dpi=600)
    ax = fig.add_subplot(111)
    for num_tc_per_run in list_tc_per_run:
        count, bins_count = np.histogram(num_tc_per_run, bins=10)
        pdf = count / sum(count)
        # using numpy np.cumsum to calculate the CDF
        # We can also find using the PDF values by looping and adding
        # cdf = np.cumsum(pdf)
        plt.plot(bins_count[1:], pdf, color="red", label="PDF")
        plt.legend()
    fig.show()


def perform_mann_whitney_u_test(csv_path, csv_path2, csv_exp_time_to_read, csv_path_random, title, label1, label2,
                                compare_with_randomunguided):
    data_exp_time = create_data_from_experiment(csv_path, csv_exp_time_to_read, False)
    # if it is compared to random, uncomment the two lines below:
    if compare_with_randomunguided:
        label2 = exp_name2 + "_" + exp_type2 + "_" + k2 + "_random"  # jsut for random
        data_exp_time_2 = create_data_from_experiment(csv_path_random, csv_exp_time_to_read, False)
    else:
        data_exp_time_2 = create_data_from_experiment(csv_path2, csv_exp_time_to_read, False)

    print("title: ", title)
    num_tc_per_run_for_experims = get_mean_min_max_between_two_exps([data_exp_time, data_exp_time_2])
    print("+============+")
    get_mann_whitney_u_test(num_tc_per_run_for_experims[0], num_tc_per_run_for_experims[1], label1, label2, title)


def generate_box_plots(base_csv_path, csv_exp_time_to_read, exp_type1, path_to_exper_folder):
    print("+============+")
    k_list = ['random', 1, 3, 5, 7]  # ['random', 1, 3, 5, 7]
    list_experiments = []
    exper_names = []
    for k_num in k_list:
        if k_num == 'random':
            for idx in 1, 3, 5, 7:
                temp_csv_random_path = path_to_exper_folder + '/{}/{}_{}/experiment_results/k_'.format(
                    exp_day, exp_name1,
                    k_num) + str(idx) + '/'  # because random is with k=1
                exper_names.append('TAF,k=' + str(idx))
                list_experiments.append(create_data_from_experiment(temp_csv_random_path, csv_exp_time_to_read, False))
        else:
            temp_csv_k_path = base_csv_path + str(k_num) + '/'
            if exp_type1 == 'tax_payer':
                exp_type1 = 'taxpayer'
            exper_names.append(exp_type1 + '=' + str(k_num))
            list_experiments.append(create_data_from_experiment(temp_csv_k_path, csv_exp_time_to_read, False))
    num_tc_per_run_for_all_experims = get_mean_min_max_between_two_exps(list_experiments)

    print("+============+")
    label = 'Test suite size'  # 'Number of test cases generated'
    fig_title = exp_name1 + ' with TAF unguided vs guided, for different k'
    box_plot_list_of_experiments(num_tc_per_run_for_all_experims, exper_names, fig_title, label)


def generate_cdf_with_quantiles(csv_path, csv_path2, csv_to_read, csv_path_random, max_num_sentences):
    print("+============+")
    data_list = create_data_from_experiment(csv_path, csv_to_read, False)
    data2compare = create_data_from_experiment(csv_path2, csv_to_read, False)
    data_from_random = create_data_from_experiment(csv_path_random, csv_to_read, False)
    cdfs = compute_cdfs([data_list, data2compare, data_from_random])
    extended_cdfs = extend_cdfs(cdfs)  # the cdfs have to have equal length to do the mean

    lists_for_quantiles = create_lists_for_comparison(extended_cdfs)

    lists_for_quantiles = [[i / max_num_sentences for i in inner] for inner in
                           lists_for_quantiles]  # normalizes the num of sentences covered

    title = 'CDF of ' + exp_name1 + ' with K=1, K=7, and TAF strategy'
    label_2 = ['Median with K=' + k1, 'Median with K=' + k2, 'Median with TAF']
    xlabel = 'Number of iterations'  # 'Number of test cases'
    ylabel = "Cumulative coverage"
    xmin = 0.8
    xmax = 9
    plot_with_quantiles(lists_for_quantiles, title, label_2, xlabel=xlabel, ylabel=ylabel, xmin=xmin, xmax=xmax)

######################################################################
#
######################################################################


def main(exp_day, exp_name1, exp_name2, k1, k2, exp_type1, exp_type2, path_to_exper_folder, compare_with_randomunguided):

    label1 = exp_name1 + "_" + exp_type1 + "_" + k1
    label2 = exp_name2 + "_" + exp_type2 + "_" + k2
    title = "comparison {} vs {}".format(label1, label2)
    base_csv_path = path_to_exper_folder + '/{}/{}_{}/experiment_results/k_'  # no k_{} , it is for the box plots
    base_csv_path = base_csv_path.format(exp_day, exp_name1, exp_type1)
    csv_path = path_to_exper_folder + '/{}/{}_{}/experiment_results/k_{}/'
    csv_path = csv_path.format(exp_day, exp_name1, exp_type1, k1)
    csv_path2 = path_to_exper_folder + '/{}/{}_{}/experiment_results/k_{}/'
    csv_path2 = csv_path2.format(exp_day, exp_name2, exp_type2, k2)
    csv_path_random = path_to_exper_folder + '/{}/{}_random/experiment_results/k_{}/'
    csv_path_random = csv_path_random.format(exp_day, exp_name2,
                                             '1')  #k2)  # '1' is because usually TAF is used with k=1
    csv_to_read = "/sentences_covered_per_tc_only_num.csv"

    csv_unsat_sent_dict_to_read = "/unsat_sentences.csv"
    csv_exp_time_to_read = "/experiment_info.csv"

    if exp_name1 == 'oz':
        max_num_sentences = 1247
    elif exp_name1 == 'tax_payer':
        max_num_sentences = 1959
    #############################################################################
    #
    #############################################################################

    print(" mann_whitney_u_test")  # between 2 experiments, e.g.,  0z_k1 and Oz_3, or Oz_k1 and Oz_k1_random
    perform_mann_whitney_u_test(csv_path, csv_path2, csv_exp_time_to_read, csv_path_random, title, label1, label2,
                                compare_with_randomunguided)

    print(" create box plots comparing the experiments, guided vs unguided")
    generate_box_plots(base_csv_path, csv_exp_time_to_read, exp_type1, path_to_exper_folder)

    print("generate_CDF_with_quantiles")
    generate_cdf_with_quantiles(csv_path, csv_path2, csv_to_read, csv_path_random, max_num_sentences)

    # print("Checking unique unsat sentences")
    # find_unique_unsat_sentences(csv_path, title,  csv_unsat_sent_dict_to_read)


if __name__ == '__main__':
    ######################################################################################
    #  Modify here the variables to analyze the experiment that you want.
    ######################################################################################
    print("This is the script to analyze the results of the experiments of the TAF+pairwise paper. \n"
          "Use it after finishing the experiments with the other script. \n"
          "Please change the parameters inside this script to select which experiments you want to analyze or compare. "
          "This script provides the diagrams and figures too, like the ones appearing inside the paper. \n"
          "Please do not change the folder structure compared to the replication package.\n"
          "You must complete all four experiments, oz_guided, oz_unguided, Taxpayer guided and unguided, "
          "before starting the analysis. \n\n")

    path_to_exper_folder = '/home/.../replication_package_pairwise'  # the path where the experiments results/files are

    exp_day = '2022.10.99'  # the experiment day, as the experiments should performed all inside a folder which name
    # is the day of the experiment. Do not change it, unless absolutely needed.

    # select which case studies you want to compare (case1 vs case2), e.g. Oz with k=1 vs oz with k=7
    exp_name1 = 'oz'
    # exp_name1 = 'tax_payer'
    exp_name2 = 'oz'
    # exp_name2 = 'tax_payer'

    k1 = '1'  # select the k value of test cases produced at each iteration for experiment 1
    k2 = '7'  # k for the second experiment

    exp_type1 = 'k'  # select the type of experiment (terminology to link to the paper: k = guided, random= unguided)
    exp_type2 = 'k'
    # exp_type1 = 'random'
    # exp_type2 = 'random'

    compare_with_randomunguided = False  # for the mann-whitneyU test comparing the two experiments selected.


    ######################################################################################
    #  Do not modify below this line
    ######################################################################################

    main(exp_day, exp_name1, exp_name2, k1, k2, exp_type1, exp_type2, path_to_exper_folder, compare_with_randomunguided)
